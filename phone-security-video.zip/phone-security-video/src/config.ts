// প্রিভিউ-সহায়ক ফ্ল্যাগ
// public/voiceover.mp3 থাকলে Studio-তে বাজবে; না থাকলে নীরবে বাদ।
export const PLAY_VOICEOVER = true; // false দিলে Studio-তেও বন্ধ
export const VOICEOVER_IN_RENDER = false; // ডিফল্টে রেন্ডারে বন্ধ (true দিলে MP4-তেও মিশবে)
