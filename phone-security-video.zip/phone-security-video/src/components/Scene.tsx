// Scene — সিনের Sequence + মাস্ক-উইপ ট্রানজিশন (কাট প্যানেলের পেছনে লুকানো)
import React from "react";
import {AbsoluteFill, Sequence, interpolate, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {SceneBase, type SceneDef} from "../timing";
import {Sfx} from "./ui";

const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

const Panels: React.FC<{x: number; accentShift: number}> = ({x, accentShift}) => (
  <AbsoluteFill style={{pointerEvents: "none", overflow: "hidden"}}>
    <div style={{position: "absolute", inset: 0, background: theme.colors.accent, transform: `translateX(${x + accentShift}%)`}} />
    <div style={{position: "absolute", inset: 0, background: theme.colors.primary, transform: `translateX(${x}%)`}} />
  </AbsoluteFill>
);

const Inner: React.FC<{def: SceneDef; children?: React.ReactNode}> = ({def, children}) => {
  const frame = useCurrentFrame();
  const dur = def.duration;
  const enter = interpolate(frame, [0, 12], [0, 1], {easing: theme.ease.inOut, ...clamp}); // প্যানেল ডানে সরে যায়
  const exit = interpolate(frame, [dur - 10, dur - 1], [0, 1], {easing: theme.ease.inOut, ...clamp}); // প্যানেল বাঁ থেকে ঢেকে দেয়
  return (
    <AbsoluteFill>
      {children}
      {def.index > 0 && enter < 1 && <Panels x={enter * 100} accentShift={-8} />}
      {!def.last && exit > 0 && <Panels x={-100 + exit * 100} accentShift={8} />}
      {!def.last && <Sfx name="swipe" at={dur - 12} vol={0.26} rate={1 + (def.index % 3) * 0.04} />}
    </AbsoluteFill>
  );
};

export const Scene: React.FC<{def: SceneDef; children?: React.ReactNode}> = ({def, children}) => (
  <Sequence from={def.from} durationInFrames={def.duration} name={def.key}>
    <SceneBase.Provider value={def.from}>
      <Inner def={def}>{children}</Inner>
    </SceneBase.Provider>
  </Sequence>
);
