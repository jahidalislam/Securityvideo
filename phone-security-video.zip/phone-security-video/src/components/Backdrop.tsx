// ৫-স্তরের নিচের ও ওপরের অংশ: ব্যাকগ্রাউন্ড মেশ (নিচে) এবং গ্রেড, গ্রেইন, ভিনিয়েট (ওপরে)
import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {alpha, theme} from "../theme";

const C = theme.colors;

export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50;
  const d2 = Math.cos(frame / 70) * 40;
  return (
    <AbsoluteFill style={{background: C.bg}}>
      <div style={{position: "absolute", width: 1200, height: 1200, borderRadius: "50%", top: -520, left: -320 + d1, filter: "blur(50px)", background: `radial-gradient(circle, ${alpha(C.primary, 0.2)}, transparent 62%)`}} />
      <div style={{position: "absolute", width: 1000, height: 1000, borderRadius: "50%", bottom: -460, right: -280 - d2, filter: "blur(70px)", background: `radial-gradient(circle, ${alpha(C.accent, 0.2)}, transparent 65%)`}} />
      <div style={{position: "absolute", inset: 0, background: `linear-gradient(180deg, transparent 55%, ${alpha(C.bgAlt, 0.7)})`}} />
    </AbsoluteFill>
  );
};

export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: "none"}}>
    <AbsoluteFill style={{backgroundColor: C.primary, mixBlendMode: "soft-light", opacity: 0.1}} />
    <AbsoluteFill style={{background: `linear-gradient(180deg, ${alpha(C.text, 0.05)}, transparent 28%, transparent 72%, ${alpha(C.text, 0.08)})`}} />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.05,
        mixBlendMode: "multiply",
      }}
    />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: "none", background: `radial-gradient(ellipse at center, transparent 58%, ${alpha(C.text, 0.12)} 100%)`}} />
);
