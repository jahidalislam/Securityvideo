// ui.tsx — সব দৃশ্যে ব্যবহৃত ছোট পুনর্ব্যবহারযোগ্য অংশ
import React from "react";
import {AbsoluteFill, Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from "remotion";
import {alpha, theme} from "../theme";
import {useAt} from "../timing";

const C = theme.colors;
export const bn = (n: number | string) => String(n).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);
const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

/* ───────── স্প্রিং ও নড়াচড়া ───────── */
export const useSpring = (delay = 0, cfg: {damping: number; stiffness: number; mass: number} = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: frame - delay, fps, config: cfg});
};
export const useBreath = (amp = 3, speed = 28, phase = 0) => Math.sin((useCurrentFrame() + phase) / speed) * amp;

/** অ্যাবসোলিউট বক্স */
export const Abs: React.FC<{x?: number; y?: number; w?: number; h?: number; center?: boolean; style?: React.CSSProperties; children?: React.ReactNode}> = ({x, y, w, h, center, style, children}) => (
  <div
    style={{
      position: "absolute",
      left: x,
      top: y,
      width: w,
      height: h,
      ...(center ? {display: "flex", alignItems: "center", justifyContent: "center"} : {}),
      ...style,
    }}
  >
    {children}
  </div>
);

/** ফেড-আউটসহ সময়-জানালা (সিন-লোকাল ফ্রেম) */
export const Win: React.FC<{from?: number; to?: number; fade?: number; children?: React.ReactNode}> = ({from = 0, to = Infinity, fade = 8, children}) => {
  const frame = useCurrentFrame();
  if (frame < from || frame >= to) return null;
  const o = Number.isFinite(to) ? interpolate(frame, [to - fade, to], [1, 0], {easing: theme.ease.in, ...clamp}) : 1;
  return <AbsoluteFill style={{opacity: o, transform: `translateY(${(1 - o) * -22}px)`}}>{children}</AbsoluteFill>;
};

/** প্রিমিয়াম এন্ট্রি: opacity + উঠে আসা + স্কেল */
export const Entrance: React.FC<{delay?: number; y?: number; x?: number; from?: number; sp?: keyof typeof theme.spring; style?: React.CSSProperties; children?: React.ReactNode}> = ({delay = 0, y = 34, x = 0, from = 0.94, sp = "smooth", style, children}) => {
  const p = useSpring(delay, theme.spring[sp]);
  return (
    <div
      style={{
        opacity: Math.min(1, p * 1.5),
        transform: `translate(${interpolate(p, [0, 1], [x, 0])}px, ${interpolate(p, [0, 1], [y, 0])}px) scale(${interpolate(p, [0, 1], [from, 1])})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** শব্দ ধরে স্ট্যাগার্ড রিভিল — বাংলা কখনো অক্ষর ধরে ভাঙে না (শুধু স্পেসে ভাগ) */
export const Words: React.FC<{text: string; delay?: number; per?: number; size?: number; weight?: number; color?: string; hi?: string[]; align?: "left" | "center"; maxWidth?: number}> = ({text, delay = 0, per = 3, size = theme.type.title, weight = theme.type.weightHeavy, color = C.text, hi = [], align = "left", maxWidth}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const words = text.split(" ").filter(Boolean);
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        columnGap: Math.round(size * 0.26),
        rowGap: Math.round(size * 0.04),
        justifyContent: align === "center" ? "center" : "flex-start",
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: weight,
        lineHeight: 1.4,
        letterSpacing: 0,
        color,
        maxWidth,
      }}
    >
      {words.map((w, i) => {
        const d = delay + i * per;
        const p = spring({frame: frame - d, fps, config: theme.spring.snappy});
        const sweep = spring({frame: frame - d - 5, fps, config: theme.spring.smooth});
        const isHi = hi.includes(w.replace(/[!?।,:]/g, ""));
        return (
          <span
            key={i}
            style={{
              position: "relative",
              display: "inline-block",
              opacity: Math.min(1, p * 1.6),
              transform: `translateY(${interpolate(p, [0, 1], [26, 0])}px) scale(${interpolate(p, [0, 1], [0.96, 1])})`,
              color: isHi ? C.primary : undefined,
            }}
          >
            {isHi && (
              <span
                style={{
                  position: "absolute",
                  left: -10,
                  right: -10,
                  top: "20%",
                  bottom: "8%",
                  borderRadius: 16,
                  background: alpha(C.primary, 0.13),
                  transform: `scaleX(${Math.max(0, sweep)})`,
                  transformOrigin: "left center",
                  zIndex: -1,
                }}
              />
            )}
            {w}
          </span>
        );
      })}
    </div>
  );
};

/* ───────── কার্ড, চিপ ───────── */
export const Card: React.FC<{glass?: boolean; style?: React.CSSProperties; children?: React.ReactNode}> = ({glass, style, children}) => (
  <div
    style={{
      background: glass ? alpha(C.surface, 0.7) : C.surface,
      backdropFilter: glass ? "blur(16px)" : undefined,
      borderRadius: theme.radius.card,
      border: `1.5px solid ${C.line}`,
      boxShadow: theme.shadow.card,
      ...style,
    }}
  >
    {children}
  </div>
);

type Tone = "neutral" | "hero" | "accent" | "dark";
const toneStyle = (t: Tone): {bg: string; fg: string; bd: string} =>
  t === "hero" ? {bg: C.primary, fg: C.onHero, bd: C.primary}
  : t === "accent" ? {bg: alpha(C.accent, 0.14), fg: C.accentDeep, bd: alpha(C.accent, 0.4)}
  : t === "dark" ? {bg: C.text, fg: C.bg, bd: C.text}
  : {bg: C.surface, fg: C.text, bd: C.line};

export const Chip: React.FC<{text: string; icon?: IconName; tone?: Tone; size?: number; delay?: number; slash?: boolean; style?: React.CSSProperties}> = ({text, icon, tone = "neutral", size = theme.type.small, delay, slash, style}) => {
  const t = toneStyle(tone);
  const body = (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: Math.round(size * 0.4),
        padding: `${Math.round(size * 0.3)}px ${Math.round(size * 0.7)}px`,
        borderRadius: theme.radius.chip,
        background: t.bg,
        color: t.fg,
        border: `1.5px solid ${t.bd}`,
        fontFamily: theme.fonts.display,
        fontWeight: theme.type.weightMid,
        fontSize: size,
        lineHeight: 1.35,
        letterSpacing: 0,
        whiteSpace: "nowrap",
        boxShadow: tone === "neutral" ? theme.shadow.soft : undefined,
        ...style,
      }}
    >
      {icon && <Icon name={icon} size={Math.round(size * 1.1)} color={t.fg} slash={slash} />}
      <span>{text}</span>
    </div>
  );
  return delay === undefined ? body : <Entrance delay={delay} y={22} sp="snappy">{body}</Entrance>;
};

export const Toggle: React.FC<{on: number; scale?: number}> = ({on, scale = 1}) => {
  const w = 170 * scale, h = 96 * scale, pad = 9 * scale;
  return (
    <div style={{position: "relative", width: w, height: h, borderRadius: h, background: alpha(C.text, 0.16), flexShrink: 0}}>
      <div style={{position: "absolute", inset: 0, borderRadius: h, background: C.accent, opacity: on}} />
      <div style={{position: "absolute", top: pad, left: pad + on * (w - h), width: h - pad * 2, height: h - pad * 2, borderRadius: h, background: C.surface, boxShadow: theme.shadow.soft}} />
    </div>
  );
};

/** পথ-নির্দেশ: Settings › Google › … */
export const Breadcrumb: React.FC<{items: string[]; times: number[]; size?: number; lastTone?: Tone}> = ({items, times, size = 34, lastTone = "hero"}) => (
  <div style={{display: "flex", flexWrap: "wrap", alignItems: "center", gap: Math.round(size * 0.35)}}>
    {items.map((it, i) => (
      <React.Fragment key={i}>
        {i > 0 && (
          <Entrance delay={times[i]} y={0} x={-10} from={1}>
            <Icon name="arrowRight" size={size} color={C.textDim} />
          </Entrance>
        )}
        <Chip text={it} size={size} tone={i === items.length - 1 ? lastTone : "neutral"} delay={times[i]} />
      </React.Fragment>
    ))}
  </div>
);

/** ধাপ-শিরোনাম: ০১ / ০৫ + শিরোনাম */
export const StepHeader: React.FC<{n: number; title: string; at: number; hi?: string[]}> = ({n, title, at, hi}) => (
  <Abs x={96} y={48} w={1728}>
    <div style={{display: "flex", alignItems: "center", gap: 32}}>
      <Entrance delay={at} y={0} x={-30} sp="bouncy">
        <Chip text={`${bn(String(n).padStart(2, "0"))} / ${bn("05")}`} tone="dark" size={40} />
      </Entrance>
      <Words text={title} delay={at + 4} per={3} size={theme.type.title - 6} hi={hi} maxWidth={1420} />
    </div>
  </Abs>
);

/** বাংলা ধাপ-শিরোনামের জন্য সহায়ক: cue থেকে লোকাল ফ্রেম */
export const useStepAt = (cue: number) => useAt(cue);

/* ───────── ফোন ফ্রেম ───────── */
export const PhoneFrame: React.FC<{w: number; style?: React.CSSProperties; children?: React.ReactNode}> = ({w, style, children}) => {
  const h = Math.round(w * 2.02);
  const bez = Math.round(w * 0.04);
  return (
    <div style={{position: "relative", width: w, height: h, borderRadius: w * 0.15, background: C.text, padding: bez, boxShadow: theme.shadow.card, flexShrink: 0, ...style}}>
      <div style={{position: "relative", width: "100%", height: "100%", borderRadius: w * 0.115, background: C.bgAlt, overflow: "hidden"}}>
        {children}
        <div style={{position: "absolute", top: w * 0.03, left: "50%", marginLeft: -w * 0.13, width: w * 0.26, height: w * 0.05, borderRadius: w, background: C.text}} />
      </div>
    </div>
  );
};

/* ───────── আইকন (SVG, থিমের রঙে) ───────── */
export type IconName = "wifi" | "plane" | "power" | "lock" | "unlock" | "shield" | "phone" | "bluetooth" | "pin" | "check" | "arrowDown" | "arrowRight" | "search" | "sliders" | "data" | "network" | "bell" | "trash" | "globe" | "alert" | "x";

const P: Record<IconName, React.ReactNode> = {
  wifi: (<><path d="M5 12.5a10 10 0 0 1 14 0" /><path d="M1.5 9a15 15 0 0 1 21 0" /><path d="M8.5 16a5.5 5.5 0 0 1 7 0" /><circle cx="12" cy="19.5" r="1" fill="currentColor" /></>),
  plane: <path d="M2.5 11.5 21.5 3l-6 18-3.5-7zM12 14 21.5 3" />,
  power: (<><path d="M12 3v9" /><path d="M17.7 6.8a8.5 8.5 0 1 1-11.4 0" /></>),
  lock: (<><rect x="4.5" y="10.5" width="15" height="10.5" rx="2.5" /><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3" /></>),
  unlock: (<><rect x="4.5" y="10.5" width="15" height="10.5" rx="2.5" /><path d="M8 10.5V7.5a4 4 0 0 1 7.4-2.1" /></>),
  shield: (<><path d="M12 2.5 19.5 5.5v6c0 4.7-3.2 8.6-7.5 10-4.3-1.4-7.5-5.3-7.5-10v-6z" /><path d="M8.5 12l2.5 2.5 4.8-5" /></>),
  phone: (<><rect x="6.5" y="2" width="11" height="20" rx="2.8" /><path d="M10.5 18.5h3" /></>),
  bluetooth: <path d="M6.5 7.5 17 16.5 12 21V3l5 4.5L6.5 16.5" />,
  pin: (<><path d="M12 22s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12z" /><circle cx="12" cy="10" r="2.6" /></>),
  check: <path d="M5 12.5l4.5 4.5L19 7" />,
  arrowDown: <path d="M12 4v15M6 13.5l6 6 6-6" />,
  arrowRight: <path d="M4 12h15M13.5 6l6 6-6 6" />,
  search: (<><circle cx="11" cy="11" r="6.5" /><path d="M20.5 20.5 16 16" /></>),
  sliders: (<><path d="M4 6h16M4 12h16M4 18h16" /><circle cx="9" cy="6" r="2" fill="currentColor" /><circle cx="15" cy="12" r="2" fill="currentColor" /><circle cx="8" cy="18" r="2" fill="currentColor" /></>),
  data: <path d="M8 20V5M4 9l4-4 4 4M16 4v15M12 15l4 4 4-4" />,
  network: (<><circle cx="12" cy="5" r="2.5" /><circle cx="5" cy="18" r="2.5" /><circle cx="19" cy="18" r="2.5" /><path d="M10.8 7.2 6.3 15.8M13.2 7.2l4.5 8.6M7.5 18h9" /></>),
  bell: (<><path d="M6 16v-5a6 6 0 0 1 12 0v5l1.5 2h-15z" /><path d="M10 21h4" /></>),
  trash: (<><path d="M5 7h14M10 7V4h4v3" /><path d="M6.5 7l1 13h9l1-13" /></>),
  globe: (<><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18" /></>),
  alert: (<><path d="M12 3 22 20H2z" /><path d="M12 10v4.5M12 17.5v.01" /></>),
  x: <path d="M6 6l12 12M18 6 6 18" />,
};

export const Icon: React.FC<{name: IconName; size?: number; color?: string; sw?: number; slash?: boolean; style?: React.CSSProperties}> = ({name, size = 48, color = C.text, sw = 1.9, slash = false, style}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" style={{display: "block", color, flexShrink: 0, ...style}}>
    {P[name]}
    {slash && (
      <>
        <path d="M3.5 3.5l17 17" stroke={C.surface} strokeWidth={sw + 3.4} />
        <path d="M3.5 3.5l17 17" />
      </>
    )}
  </svg>
);

/* ───────── সাউন্ড ───────── */
export type SfxName = "pop" | "click" | "whoosh" | "swipe" | "chime" | "thud";
const SFX_SEC: Record<SfxName, number> = {pop: 0.2, click: 0.09, whoosh: 0.7, swipe: 0.36, chime: 0.5, thud: 0.34};

/** ভিজ্যুয়াল নামার ২ ফ্রেম আগে শুরু হয় (আগে বাজলে সিঙ্ক ভালো লাগে) */
export const Sfx: React.FC<{name: SfxName; at: number; vol?: number; rate?: number}> = ({name, at, vol = 0.3, rate = 1}) => {
  const {fps} = useVideoConfig();
  return (
    <Sequence from={Math.max(0, Math.round(at) - 2)} durationInFrames={Math.ceil((SFX_SEC[name] / rate) * fps) + 2} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={vol} playbackRate={rate} />
    </Sequence>
  );
};
