// PreviewAudio — public/voiceover.mp3 থাকলে Studio-তে বাজে, না থাকলে নীরবে বাদ।
// ডিফল্টে MP4 রেন্ডারে বন্ধ (src/config.ts-এর ফ্ল্যাগ দেখুন)।
import React, {useEffect, useState} from "react";
import {Audio, continueRender, delayRender, staticFile, useRemotionEnvironment} from "remotion";
import {PLAY_VOICEOVER, VOICEOVER_IN_RENDER} from "../config";

export const PreviewAudio: React.FC = () => {
  const env = useRemotionEnvironment();
  const allowed = PLAY_VOICEOVER && (env.isRendering ? VOICEOVER_IN_RENDER : true);
  const [handle] = useState(() => (allowed ? delayRender("voiceover.mp3 আছে কি না দেখা হচ্ছে") : null));
  const [ok, setOk] = useState(false);

  useEffect(() => {
    if (!allowed || handle === null) return;
    let alive = true;
    fetch(staticFile("voiceover.mp3"), {method: "HEAD"})
      .then((r) => {
        if (alive) setOk(r.ok && (r.headers.get("content-type") ?? "").startsWith("audio"));
      })
      .catch(() => undefined)
      .finally(() => continueRender(handle));
    return () => {
      alive = false;
    };
  }, [allowed, handle]);

  if (!allowed || !ok) return null;
  return <Audio src={staticFile("voiceover.mp3")} />;
};
