// সিন ৩ — ওভারভিউ (cue ১৭–২৫): ৫টি সেটিংসের কার্ড-সারি (Bento/Carousel ধাঁচ, কাউন্টারসহ)
import React from "react";
import {Abs, Chip, Entrance, Icon, Sfx, Win, Words, bn, useSpring, type IconName} from "../components/ui";
import {alpha, theme} from "../theme";
import {useAt, useSpread} from "../timing";

const C = theme.colors;

const ITEMS: {icon: IconName; label: string; sub: string}[] = [
  {icon: "sliders", label: "Quick Settings", sub: "লক স্ক্রিন থেকে বন্ধ"},
  {icon: "power", label: "Power Off", sub: "পাসওয়ার্ড লাগবে"},
  {icon: "shield", label: "Theft Protection", sub: "Google-এর সুরক্ষা"},
  {icon: "pin", label: "Find Hub", sub: "অফলাইনেও খোঁজা"},
  {icon: "lock", label: "Remote Lock", sub: "দূর থেকে লক"},
];

const W = 310;
const GAP = 28;
const X0 = (1920 - (5 * W + 4 * GAP)) / 2;

const Tile: React.FC<{i: number; at: number; hl: number}> = ({i, at, hl}) => {
  const it = ITEMS[i];
  const last = i === 4;
  const dim = last ? 0 : hl * 0.4;
  return (
    <Abs x={X0 + i * (W + GAP)} y={310} w={W} h={470} style={{opacity: 1 - dim, transform: `scale(${last ? 1 + hl * 0.06 : 1})`, transformOrigin: "50% 60%"}}>
      <Entrance delay={at} y={60} sp="bouncy" from={0.9}>
        <div
          style={{
            height: 470,
            borderRadius: theme.radius.card,
            background: C.surface,
            border: `1.5px solid ${C.line}`,
            boxShadow: `${last ? `0 0 0 ${5 * hl}px ${alpha(C.primary, hl)}, ` : ""}${theme.shadow.card}`,
            padding: 30,
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
          }}
        >
          <div style={{fontSize: 46, fontWeight: theme.type.weightHeavy, color: last && hl > 0.5 ? C.primary : C.textDim, letterSpacing: 0, lineHeight: 1.3}}>{bn(`0${i + 1}`)}</div>
          <div style={{width: 128, height: 128, borderRadius: theme.radius.tile, background: alpha(C.accent, 0.14), display: "flex", alignItems: "center", justifyContent: "center"}}>
            <Icon name={it.icon} size={70} color={C.accentDeep} sw={1.7} />
          </div>
          <div>
            <div style={{fontSize: 36, fontWeight: theme.type.weightHeavy, lineHeight: 1.25, letterSpacing: 0}}>{it.label}</div>
            <div style={{fontSize: 28, fontWeight: theme.type.weightBody, color: C.textDim, lineHeight: 1.4, marginTop: 6, letterSpacing: 0}}>{it.sub}</div>
          </div>
        </div>
      </Entrance>
    </Abs>
  );
};

export const S3Preview: React.FC = () => {
  const t17 = useAt(17);
  const t20 = useAt(20);
  const t22 = useAt(22);
  const t25 = useAt(25);
  const at = useSpread(17, 19, 5);
  const hl = useSpring(t20, theme.spring.smooth);

  return (
    <>
      <Abs x={160} y={80} w={1600}>
        <Words text="৫টি সিকিউরিটি সেটিংস" delay={t17} per={4} size={96} align="center" hi={["৫টি"]} />
      </Abs>

      {ITEMS.map((_, i) => (
        <Tile key={i} i={i} at={at[i]} hl={Math.max(0, hl)} />
      ))}

      <Win from={t20} to={t22}>
        <Abs x={0} y={850} w={1920} center><Chip text="শেষের সেটিংসটি খুবই গুরুত্বপূর্ণ" tone="dark" size={42} delay={t20} /></Abs>
      </Win>
      <Win from={t22} to={t25}>
        <Abs x={0} y={850} w={1920} center><Chip text="ইন্টারনেটের বাইরে গেলেও কাছাকাছি ডিভাইসের সাহায্যে খোঁজা যায়" icon="bluetooth" tone="accent" size={36} delay={t22} /></Abs>
      </Win>
      <Win from={t25}>
        <Abs x={0} y={845} w={1920} center><Chip text="চলুন, শুরু করা যাক" tone="hero" size={52} delay={t25} /></Abs>
      </Win>

      <Sfx name="whoosh" at={t17} vol={0.22} />
      <Sfx name="pop" at={at[0]} vol={0.3} />
      <Sfx name="pop" at={at[3]} vol={0.28} rate={1.06} />
      <Sfx name="chime" at={t20} vol={0.28} />
      <Sfx name="click" at={t25} vol={0.3} />
    </>
  );
};
