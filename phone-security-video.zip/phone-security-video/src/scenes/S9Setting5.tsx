// সিন ৯ — সেটিংস ৫: Remote Lock + সমাপ্তি-চেকলিস্ট (cue ১৬৯–২০১)
import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {Abs, Breadcrumb, Card, Chip, Entrance, Icon, PhoneFrame, Sfx, StepHeader, Toggle, Win, Words, useBreath, useSpring, type IconName} from "../components/ui";
import {alpha, theme} from "../theme";
import {useAt, useSpread} from "../timing";

const C = theme.colors;
const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

const MiniPhone: React.FC<{icon: IconName; slash?: boolean; dim?: boolean; color?: string}> = ({icon, slash, dim, color = C.accentDeep}) => (
  <PhoneFrame w={250} style={{opacity: dim ? 0.6 : 1}}>
    <Abs x={0} y={0} w={234} h={490} center>
      <Icon name={icon} size={100} color={color} sw={1.6} slash={slash} />
    </Abs>
  </PhoneFrame>
);

const FlowCard: React.FC<{icon: IconName; slash?: boolean; label: string; delay: number}> = ({icon, slash, label, delay}) => (
  <Entrance delay={delay} y={40} sp="bouncy" from={0.9}>
    <Card style={{width: 480, height: 330, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 24}}>
      <div style={{width: 130, height: 130, borderRadius: "50%", background: alpha(C.accent, 0.14), display: "flex", alignItems: "center", justifyContent: "center"}}>
        <Icon name={icon} size={72} color={C.accentDeep} sw={1.7} slash={slash} />
      </div>
      <div style={{fontSize: 42, fontWeight: theme.type.weightHeavy, letterSpacing: 0, lineHeight: 1.3, textAlign: "center", padding: "0 20px"}}>{label}</div>
    </Card>
  </Entrance>
);

const URL_TEXT = "android.com/lock";

export const S9Setting5: React.FC = () => {
  const frame = useCurrentFrame();
  const t169 = useAt(169);
  const t171 = useAt(171);
  const t173 = useAt(173);
  const t174 = useAt(174);
  const t175 = useAt(175);
  const t178 = useAt(178);
  const t180 = useAt(180);
  const t181 = useAt(181);
  const t182 = useAt(182);
  const t184 = useAt(184);
  const t186 = useAt(186);
  const t187 = useAt(187);
  const t188 = useAt(188);
  const t190 = useAt(190);
  const t191 = useAt(191);
  const t193 = useAt(193);
  const t194 = useAt(194);
  const t195 = useAt(195);
  const t196 = useAt(196);
  const t197 = useAt(197);
  const chk = useSpread(199, 201, 3);
  const float = useBreath(6, 26);
  const on = interpolate(frame, [t186, t186 + 12], [0, 1], {easing: theme.ease.out, ...clamp});
  const locked = frame >= t180 + 8;
  const lockPop = useSpring(t180 + 8, theme.spring.bouncy);
  const typed = Math.round(interpolate(frame, [t190, t190 + 14], [0, URL_TEXT.length], {...clamp}));
  const arrowShift = (frame * 2) % 40;

  return (
    <>
      <StepHeader n={5} title="Remote Lock চালু রাখুন" at={t169} hi={["Remote"]} />

      {/* ক: ফোন চুরি হয়েছে, হাতে অন্য ফোন */}
      <Win from={t171} to={t175}>
        <Abs x={160} y={205} w={1600}><Words text="ফোনটি চুরি হয়ে গেছে" delay={t171} size={72} align="center" hi={["চুরি"]} /></Abs>
        <Abs x={500} y={330} style={{transform: `translateY(${float}px)`}}><Entrance delay={t171 + 4} sp="smooth" y={50}><MiniPhone icon="alert" dim color={C.textDim} /></Entrance></Abs>
        <Abs x={1170} y={330} style={{transform: `translateY(${-float}px)`}}><Entrance delay={t173} sp="bouncy" y={50}><MiniPhone icon="phone" /></Entrance></Abs>
        <Abs x={760} y={500} w={400} h={100} center>
          <Entrance delay={t173 + 6} x={-20} y={0}><Icon name="arrowRight" size={110} color={C.textDim} sw={1.5} /></Entrance>
        </Abs>
        <Abs x={0} y={880} w={1920} center><Chip text="এখন কী করবেন?" tone="hero" size={60} delay={t174} /></Abs>
      </Win>

      {/* খ: Remote Lock ধারণা */}
      <Win from={t175} to={t181}>
        <Abs x={0} y={205} w={1920} center><Chip text="Google-এর Remote Lock ফিচার" icon="lock" tone="dark" size={52} delay={t175} /></Abs>
        <Abs x={330} y={380}><Entrance delay={t175 + 4} sp="smooth" y={50}><MiniPhone icon="phone" /></Entrance></Abs>
        <Abs x={640} y={540} w={640} h={110} style={{overflow: "hidden"}}>
          <Entrance delay={t178} x={-30} y={0}>
            <div style={{display: "flex", gap: 20, transform: `translateX(${arrowShift}px)`, marginLeft: -40}}>
              {[0, 1, 2, 3, 4, 5, 6].map((k) => <Icon key={k} name="arrowRight" size={90} color={alpha(C.text, 0.35)} sw={1.6} />)}
            </div>
          </Entrance>
        </Abs>
        <Abs x={1340} y={380}>
          <Entrance delay={t178} sp="smooth" y={50}>
            <PhoneFrame w={250}>
              <Abs x={0} y={0} w={234} h={490} center>
                <div style={{width: 150, height: 150, borderRadius: "50%", background: locked ? C.accent : alpha(C.text, 0.1), display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${locked ? Math.max(0.6, lockPop) : 1})`}}>
                  <Icon name={locked ? "lock" : "unlock"} size={80} color={locked ? C.onHero : C.textDim} sw={1.8} />
                </div>
              </Abs>
            </PhoneFrame>
          </Entrance>
        </Abs>
        <Abs x={160} y={900} w={1600}><Words text="অন্য ডিভাইস থেকে ফোনের স্ক্রিন রিমোটলি লক" delay={t178} per={3} size={54} align="center" weight={theme.type.weightHeavy} /></Abs>
      </Win>

      {/* গ: চালু করার পথ */}
      <Win from={t181} to={t188}>
        <Abs x={96} y={225} w={1730}>
          <Breadcrumb items={["Settings", "Google", "All Services", "Theft Protection", "Remote Lock"]} times={[t181, t182, t182 + 8, t184, t184 + 8]} size={36} />
        </Abs>
        <Abs x={410} y={420}>
          <Entrance delay={t186 - 6} y={40}>
            <Card style={{width: 1100, padding: "44px 56px", display: "flex", alignItems: "center", gap: 36}}>
              <Icon name="lock" size={84} color={C.accentDeep} sw={1.6} />
              <div style={{flex: 1, fontSize: 60, fontWeight: theme.type.weightHeavy, letterSpacing: 0, lineHeight: 1.3}}>Remote Lock</div>
              <Toggle on={on} scale={1.05} />
            </Card>
          </Entrance>
        </Abs>
        <Abs x={410} y={650}><Chip text="প্রয়োজনে ফোন নম্বর Verify করুন" icon="phone" tone="accent" size={42} delay={t187} /></Abs>
      </Win>

      {/* ঘ: ব্রাউজার — android.com/lock */}
      <Win from={t188} to={t194}>
        <Abs x={310} y={235}>
          <Entrance delay={t188} y={50}>
            <Card style={{width: 1300, height: 640, overflow: "hidden"}}>
              <div style={{height: 100, background: alpha(C.text, 0.05), display: "flex", alignItems: "center", gap: 14, padding: "0 32px", borderBottom: `1.5px solid ${C.line}`}}>
                {[0, 1, 2].map((k) => <div key={k} style={{width: 18, height: 18, borderRadius: "50%", background: alpha(C.text, 0.2)}} />)}
                <div style={{flex: 1, marginLeft: 24, height: 60, borderRadius: 30, background: C.surface, border: `1.5px solid ${C.line}`, display: "flex", alignItems: "center", gap: 16, padding: "0 26px"}}>
                  <Icon name="globe" size={34} color={C.textDim} />
                  <div style={{fontSize: 36, fontWeight: theme.type.weightMid, letterSpacing: 0, color: C.text}}>{URL_TEXT.slice(0, typed)}</div>
                </div>
              </div>
              <div style={{padding: "50px 70px", display: "flex", flexDirection: "column", gap: 34}}>
                <Entrance delay={t191} y={20}>
                  <div style={{display: "flex", alignItems: "center", gap: 24, height: 96, borderRadius: 24, border: `1.5px solid ${C.line}`, background: alpha(C.text, 0.03), padding: "0 30px"}}>
                    <Icon name="phone" size={50} color={C.accentDeep} />
                    <div style={{fontSize: 40, fontWeight: theme.type.weightMid, color: C.textDim, letterSpacing: 0}}>আপনার ফোন নম্বর</div>
                  </div>
                </Entrance>
                <div><Chip text="লক করার অনুরোধ পাঠান" icon="lock" tone="hero" size={44} delay={t193} /></div>
              </div>
            </Card>
          </Entrance>
        </Abs>
      </Win>

      {/* ঙ: অফলাইনে থাকলেও */}
      <Win from={t194} to={t197}>
        <Abs x={96} y={420}><FlowCard icon="wifi" slash label="ফোন অফলাইনে" delay={t194} /></Abs>
        <Abs x={576} y={540} w={144} h={100} center><Entrance delay={t195} x={-20} y={0}><Icon name="arrowRight" size={90} color={C.textDim} sw={1.6} /></Entrance></Abs>
        <Abs x={720} y={420}><FlowCard icon="wifi" label="পরে ইন্টারনেটে যুক্ত" delay={t195} /></Abs>
        <Abs x={1200} y={540} w={144} h={100} center><Entrance delay={t196} x={-20} y={0}><Icon name="arrowRight" size={90} color={C.textDim} sw={1.6} /></Entrance></Abs>
        <Abs x={1344} y={420}><FlowCard icon="lock" label="লক কার্যকর হতে পারে" delay={t196} /></Abs>
        <Abs x={160} y={225} w={1600}><Words text="অফলাইনে থাকলেও অনুরোধ কাজ করতে পারে" delay={t194} size={68} align="center" hi={["অফলাইনে"]} /></Abs>
      </Win>

      {/* চ: শর্ত-চেকলিস্ট (সমাপ্তি) */}
      <Win from={t197}>
        <Abs x={160} y={215} w={1600}><Words text="আগে থেকে কিছু শর্ত পূরণ করতে হয়" delay={t197} size={72} align="center" hi={["শর্ত"]} /></Abs>
        {(["Find Hub চালু থাকা", "ফোন নম্বর ভেরিফাই করা", "প্রয়োজনীয় নেটওয়ার্ক সংযোগ থাকা"] as const).map((text, i) => (
          <Abs key={text} x={410} y={390 + i * 175}>
            <Entrance delay={chk[i]} x={-40} y={0} sp="snappy">
              <Card style={{width: 1100, height: 135, padding: "0 44px", display: "flex", alignItems: "center", gap: 32}}>
                <div style={{width: 72, height: 72, borderRadius: "50%", background: C.accent, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0}}>
                  <Icon name="check" size={44} color={C.onHero} sw={2.8} />
                </div>
                <div style={{fontSize: 50, fontWeight: theme.type.weightHeavy, letterSpacing: 0, lineHeight: 1.3}}>{text}</div>
              </Card>
            </Entrance>
          </Abs>
        ))}
      </Win>

      <Sfx name="whoosh" at={t169} vol={0.22} />
      <Sfx name="pop" at={t171 + 4} vol={0.28} />
      <Sfx name="pop" at={t173} vol={0.3} rate={1.06} />
      <Sfx name="click" at={t174} vol={0.3} />
      <Sfx name="chime" at={t175} vol={0.26} />
      <Sfx name="chime" at={t180 + 8} vol={0.28} rate={0.94} />
      <Sfx name="click" at={t182} vol={0.28} />
      <Sfx name="click" at={t186} vol={0.32} />
      <Sfx name="pop" at={t188} vol={0.28} />
      <Sfx name="click" at={t190} vol={0.28} rate={1.05} />
      <Sfx name="click" at={t193} vol={0.32} />
      <Sfx name="pop" at={t194} vol={0.28} />
      <Sfx name="pop" at={t196} vol={0.28} rate={1.06} />
      <Sfx name="click" at={chk[0]} vol={0.3} />
      <Sfx name="click" at={chk[1]} vol={0.3} rate={1.05} />
      <Sfx name="chime" at={chk[2]} vol={0.28} />
    </>
  );
};
