// সিন ৪ — চোর কীভাবে নিয়ন্ত্রণ নেয় (cue ২৬–৪৫): Timeline/Process Flow + Glossy UI Mockup
import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {Abs, Card, Chip, Entrance, Icon, PhoneFrame, Sfx, Win, Words, useSpring, type IconName} from "../components/ui";
import {alpha, theme} from "../theme";
import {useAt, useSpread} from "../timing";

const C = theme.colors;
const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

const Node: React.FC<{icon: IconName; slash?: boolean; title: string; sub?: string; delay: number; n: number; last?: boolean}> = ({icon, slash, title, sub, delay, n, last}) => {
  const line = useSpring(delay + 8, theme.spring.smooth);
  return (
    <div style={{position: "relative"}}>
      <Entrance delay={delay} x={-40} y={0} sp="smooth">
        <Card style={{width: 900, height: 150, padding: "0 36px", display: "flex", alignItems: "center", gap: 28}}>
          <div style={{width: 84, height: 84, borderRadius: theme.radius.tile, background: alpha(C.accent, 0.14), display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0}}>
            <Icon name={icon} size={50} color={C.accentDeep} slash={slash} />
          </div>
          <div style={{flex: 1}}>
            <div style={{fontSize: 44, fontWeight: theme.type.weightHeavy, lineHeight: 1.3, letterSpacing: 0}}>{title}</div>
            {sub && <div style={{fontSize: 30, color: C.textDim, fontWeight: theme.type.weightBody, lineHeight: 1.35, letterSpacing: 0}}>{sub}</div>}
          </div>
        </Card>
      </Entrance>
      {!last && <div style={{position: "absolute", left: 78, top: 150, width: 6, height: 58 * Math.max(0, line), background: alpha(C.text, 0.2), borderRadius: 6}} />}
    </div>
  );
};

const QTile: React.FC<{icon: IconName; label: string; progress: number; invert?: boolean}> = ({icon, label, progress, invert}) => {
  // progress ০→১: ব্যবহারকারী/চোর টাইলটি বদলাচ্ছে
  const active = invert ? progress : 1 - progress;
  const color = invert ? C.primary : C.accent;
  return (
    <div style={{width: 92, textAlign: "center"}}>
      <div style={{position: "relative", width: 92, height: 92, borderRadius: 28, background: alpha(C.text, 0.1), display: "flex", alignItems: "center", justifyContent: "center"}}>
        <div style={{position: "absolute", inset: 0, borderRadius: 28, background: color, opacity: active}} />
        <div style={{position: "relative"}}><Icon name={icon} size={46} color={active > 0.5 ? C.onHero : C.textDim} slash={!invert && progress > 0.5 && icon === "wifi"} /></div>
      </div>
      <div style={{fontSize: 20, lineHeight: 1.25, marginTop: 8, fontWeight: theme.type.weightMid, letterSpacing: 0}}>{label}</div>
    </div>
  );
};

export const S4Thief: React.FC = () => {
  const frame = useCurrentFrame();
  const t26 = useAt(26);
  const t28 = useAt(28);
  const t30 = useAt(30);
  const t32 = useAt(32);
  const t34 = useAt(34);
  const t39 = useAt(39);
  const t40 = useAt(40);
  const t42 = useAt(42);
  const t43 = useAt(43);
  const tog = useSpread(37, 38, 3); // cue-র সময়ে সমান ব্যবধান
  const sheet = useSpring(t34, theme.spring.smooth);
  const p = (i: number) => interpolate(frame, [tog[i], tog[i] + 10], [0, 1], {easing: theme.ease.out, ...clamp});

  return (
    <>
      <Abs x={96} y={56} w={1100}><Words text="চোর কীভাবে নিয়ন্ত্রণ নেয়" delay={t26} size={76} hi={["নিয়ন্ত্রণ"]} /></Abs>

      {/* প্রসেস ফ্লো: cue ২৮–৩৮ */}
      <Win from={t28} to={t39}>
        <Abs x={96} y={250}><Node icon="phone" title="ফোন ছিনিয়ে নিল" sub="আনলক অবস্থায়" delay={t28} n={1} /></Abs>
        <Abs x={96} y={458}><Node icon="wifi" slash title="ইন্টারনেট সংযোগ বন্ধ" delay={t30} n={2} /></Abs>
        <Abs x={96} y={666}><Node icon="pin" title="অনলাইনে থাকলেই লোকেট ও রিমোট লক" delay={t32} n={3} last /></Abs>
      </Win>

      {/* তুলনা: cue ৩৯–৪৫ */}
      <Win from={t39}>
        <Abs x={96} y={210} w={1100}><Words text="সব ফোনে একই নয়" delay={t39} size={80} hi={["একই"]} /></Abs>
        <Abs x={96} y={385}>
          <Entrance delay={t40} x={-40} y={0}>
            <Card style={{width: 900, height: 140, padding: "0 36px", display: "flex", alignItems: "center", gap: 26}}>
              <Icon name="unlock" size={64} color={C.accentDeep} />
              <div style={{fontSize: 46, fontWeight: theme.type.weightHeavy, letterSpacing: 0, lineHeight: 1.35}}>লক স্ক্রিন থেকেই কন্ট্রোল</div>
            </Card>
          </Entrance>
        </Abs>
        <Abs x={96} y={555}>
          <Entrance delay={t42} x={-40} y={0}>
            <Card style={{width: 900, height: 140, padding: "0 36px", display: "flex", alignItems: "center", gap: 26}}>
              <Icon name="lock" size={64} color={C.accentDeep} />
              <div style={{fontSize: 46, fontWeight: theme.type.weightHeavy, letterSpacing: 0, lineHeight: 1.35}}>কিছু ফোনে পাসওয়ার্ড লাগে</div>
            </Card>
          </Entrance>
        </Abs>
        <Abs x={96} y={770}><Chip text="লক থাকা অবস্থায় কী বদলানো যায়, দেখুন" icon="search" tone="hero" size={42} delay={t43} /></Abs>
      </Win>

      {/* ফোন: লক স্ক্রিন + Quick Settings প্যানেল */}
      <Abs x={1290} y={190}>
        <Entrance delay={t26 + 4} sp="smooth" y={50}>
          <PhoneFrame w={380}>
            <Abs x={0} y={0} w={352} h={750} center style={{flexDirection: "column", gap: 20, paddingTop: 140}}>
              <Icon name="lock" size={86} color={alpha(C.text, 0.5)} sw={1.6} />
              <div style={{width: 170, height: 12, borderRadius: 12, background: alpha(C.text, 0.12)}} />
              <div style={{width: 120, height: 12, borderRadius: 12, background: alpha(C.text, 0.08)}} />
            </Abs>
            <Abs x={0} y={0} w={352} style={{background: alpha(C.surface, 0.96), borderRadius: "0 0 34px 34px", boxShadow: theme.shadow.card, padding: "64px 16px 22px", display: "flex", justifyContent: "space-between", transform: `translateY(${(1 - Math.max(0, Math.min(1, sheet))) * -110}%)`}}>
              <QTile icon="wifi" label="Wi-Fi" progress={p(0)} />
              <QTile icon="data" label="Mobile Data" progress={p(1)} />
              <QTile icon="plane" label="Airplane Mode" progress={p(2)} invert />
            </Abs>
          </PhoneFrame>
        </Entrance>
      </Abs>

      <Sfx name="whoosh" at={t26} vol={0.22} />
      <Sfx name="pop" at={t28} vol={0.3} />
      <Sfx name="pop" at={t30} vol={0.3} rate={1.05} />
      <Sfx name="pop" at={t32} vol={0.3} rate={0.95} />
      <Sfx name="swipe" at={t34} vol={0.2} rate={1.1} />
      <Sfx name="click" at={tog[0] + 2} vol={0.3} />
      <Sfx name="click" at={tog[1] + 2} vol={0.3} rate={1.05} />
      <Sfx name="click" at={tog[2] + 2} vol={0.3} rate={0.95} />
      <Sfx name="whoosh" at={t39} vol={0.2} rate={1.05} />
      <Sfx name="pop" at={t40} vol={0.3} />
      <Sfx name="pop" at={t42} vol={0.3} rate={1.06} />
      <Sfx name="click" at={t43} vol={0.3} />
    </>
  );
};
