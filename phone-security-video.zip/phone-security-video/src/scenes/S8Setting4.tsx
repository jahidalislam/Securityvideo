// সিন ৮ — সেটিংস ৪: Find Hub অফলাইন ফাইন্ডিং (cue ১২৫–১৬৮): পাঁচটি পর্ব, Hub-and-Spoke সহ
import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {Abs, Card, Chip, Entrance, Icon, PhoneFrame, Sfx, StepHeader, Win, Words, useSpring, type IconName} from "../components/ui";
import {alpha, theme} from "../theme";
import {useAt, useSpread} from "../timing";

const C = theme.colors;
const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

const Cap: React.FC<{icon: IconName; text: string; delay: number}> = ({icon, text, delay}) => (
  <Entrance delay={delay} y={26} sp="snappy">
    <Card style={{width: 520, height: 150, padding: "0 32px", display: "flex", alignItems: "center", gap: 24}}>
      <div style={{width: 84, height: 84, borderRadius: theme.radius.tile, background: alpha(C.accent, 0.14), display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0}}>
        <Icon name={icon} size={48} color={C.accentDeep} />
      </div>
      <div style={{fontSize: 40, fontWeight: theme.type.weightHeavy, letterSpacing: 0, lineHeight: 1.3}}>{text}</div>
    </Card>
  </Entrance>
);

const Step: React.FC<{n: number; text: string; delay: number; last?: boolean}> = ({n, text, delay, last}) => (
  <Entrance delay={delay} x={50} y={0} sp="smooth">
    <Card style={{width: 1000, height: 104, padding: "0 32px", display: "flex", alignItems: "center", gap: 26, border: last ? `3px solid ${C.primary}` : undefined}}>
      <div style={{width: 60, height: 60, borderRadius: "50%", background: last ? C.primary : C.text, color: C.onHero, fontSize: 34, fontWeight: theme.type.weightHeavy, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0}}>{n}</div>
      <div style={{fontSize: 40, fontWeight: theme.type.weightMid, letterSpacing: 0, lineHeight: 1.3}}>{text}</div>
    </Card>
  </Entrance>
);

const Node: React.FC<{cx: number; cy: number; d: number; icon: IconName; label: string; delay: number; slash?: boolean; badge?: IconName; tone?: "dark" | "accent"}> = ({cx, cy, d, icon, label, delay, slash, badge, tone = "accent"}) => (
  <Abs x={cx - 190} y={cy - d / 2} w={380}>
    <Entrance delay={delay} sp="bouncy" from={0.6} y={20}>
      <div style={{display: "flex", flexDirection: "column", alignItems: "center", gap: 14}}>
        <div style={{position: "relative", width: d, height: d, borderRadius: "50%", background: tone === "dark" ? C.text : C.surface, border: `1.5px solid ${C.line}`, boxShadow: theme.shadow.card, display: "flex", alignItems: "center", justifyContent: "center"}}>
          <Icon name={icon} size={d * 0.5} color={tone === "dark" ? C.bg : C.accentDeep} sw={1.7} slash={slash} />
          {badge && (
            <div style={{position: "absolute", right: -6, bottom: -6, width: d * 0.38, height: d * 0.38, borderRadius: "50%", background: C.primary, display: "flex", alignItems: "center", justifyContent: "center"}}>
              <Icon name={badge} size={d * 0.22} color={C.onHero} sw={2.2} />
            </div>
          )}
        </div>
        <div style={{fontSize: 32, fontWeight: theme.type.weightHeavy, textAlign: "center", lineHeight: 1.3, letterSpacing: 0, width: 380}}>{label}</div>
      </div>
    </Entrance>
  </Abs>
);

const Link: React.FC<{x1: number; y1: number; x2: number; y2: number; start: number; dashed?: boolean; packet?: IconName; packetAt?: number}> = ({x1, y1, x2, y2, start, dashed, packet, packetAt}) => {
  const frame = useCurrentFrame();
  const draw = interpolate(frame, [start, start + 18], [0, 1], {easing: theme.ease.out, ...clamp});
  const len = Math.hypot(x2 - x1, y2 - y1);
  const mv = packet && packetAt !== undefined ? interpolate(frame, [packetAt, packetAt + 26], [0, 1], {easing: theme.ease.inOut, ...clamp}) : -1;
  return (
    <>
      <svg width={1920} height={1080} style={{position: "absolute", left: 0, top: 0, pointerEvents: "none"}}>
        <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={dashed ? C.accent : alpha(C.text, 0.3)} strokeWidth={6} strokeLinecap="round" strokeDasharray={dashed ? "4 16" : `${len}`} strokeDashoffset={dashed ? -frame * 0.8 : len * (1 - draw)} opacity={dashed ? draw : 1} />
      </svg>
      {packet && mv >= 0 && mv < 1 && (
        <Abs x={x1 + (x2 - x1) * mv - 34} y={y1 + (y2 - y1) * mv - 34}>
          <div style={{width: 68, height: 68, borderRadius: "50%", background: C.primary, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: theme.shadow.soft}}>
            <Icon name={packet} size={36} color={C.onHero} sw={2.2} />
          </div>
        </Abs>
      )}
    </>
  );
};

export const S8Setting4: React.FC = () => {
  const frame = useCurrentFrame();
  const t125 = useAt(125);
  const t129 = useAt(129);
  const cap = useSpread(131, 133, 4);
  const t135 = useAt(135);
  const t137 = useAt(137);
  const t138 = useAt(138);
  const t139 = useAt(139);
  const t140 = useAt(140);
  const t142 = useAt(142);
  const t143 = useAt(143);
  const t145 = useAt(145);
  const t146 = useAt(146);
  const t148 = useAt(148);
  const t150 = useAt(150);
  const t153 = useAt(153);
  const t155 = useAt(155);
  const t157 = useAt(157);
  const t160 = useAt(160);
  const t162 = useAt(162);
  const fac = useSpread(162, 164, 3);
  const t166 = useAt(166);
  const rec = useSpread(166, 168, 3);
  const sel = useSpring(t143, theme.spring.snappy);
  const pulse = (frame % 36) / 36;

  return (
    <>
      <StepHeader n={4} title="Find Hub: অফলাইনেও ফোন খোঁজা অন রাখুন" at={t125} hi={["অফলাইনেও"]} />

      {/* পর্ব ক: Find My Device কী করে, তারপর Offline Finding */}
      <Win from={t129} to={t137}>
        <Abs x={96} y={205} w={1100}><Words text="Find My Device" delay={t129} size={76} hi={["Find"]} /></Abs>
        <Abs x={96} y={385}><Cap icon="pin" text="লোকেশন দেখা" delay={cap[0]} /></Abs>
        <Abs x={646} y={385}><Cap icon="bell" text="ফোনে রিং বাজানো" delay={cap[1]} /></Abs>
        <Abs x={96} y={565}><Cap icon="lock" text="রিমোটলি লক করা" delay={cap[2]} /></Abs>
        <Abs x={646} y={565}><Cap icon="trash" text="প্রয়োজনে ডাটা ডিলিট" delay={cap[3]} /></Abs>
        <Abs x={1220} y={385}>
          <Entrance delay={t135} x={60} y={0} sp="bouncy" from={0.88}>
            <div style={{width: 604, height: 330, borderRadius: theme.radius.card, background: C.text, color: C.bg, padding: 40, display: "flex", flexDirection: "column", justifyContent: "space-between", boxShadow: theme.shadow.card}}>
              <Icon name="wifi" size={92} color={C.bg} sw={1.6} slash />
              <div>
                <div style={{fontSize: 54, fontWeight: theme.type.weightHeavy, lineHeight: 1.25, letterSpacing: 0}}>Offline Finding</div>
                <div style={{fontSize: 32, fontWeight: theme.type.weightBody, opacity: 0.8, lineHeight: 1.4, letterSpacing: 0}}>আরও একটি গুরুত্বপূর্ণ সুবিধা</div>
              </div>
            </div>
          </Entrance>
        </Abs>
      </Win>

      {/* পর্ব খ: পথ-নির্দেশ + ফোন */}
      <Win from={t137} to={t145}>
        <Abs x={170} y={225}>
          <Entrance delay={t137} sp="smooth" y={60}>
            <PhoneFrame w={380}>
              <Abs x={26} y={100} w={300}><Words text="Find Hub" delay={t138} size={40} /></Abs>
              <Abs x={22} y={190} w={308}>
                <div style={{background: C.surface, borderRadius: 26, border: `1.5px solid ${C.line}`, padding: "20px 22px", fontSize: 28, fontWeight: theme.type.weightHeavy, lineHeight: 1.3, letterSpacing: 0}}>Find your offline devices</div>
              </Abs>
              <Abs x={22} y={310} w={308}>
                <div style={{position: "relative", background: C.surface, borderRadius: 26, border: `1.5px solid ${C.line}`, padding: "20px 22px", display: "flex", alignItems: "center", gap: 14}}>
                  <div style={{width: 40, height: 40, borderRadius: "50%", border: `3px solid ${C.accent}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0}}>
                    <div style={{width: 20, height: 20, borderRadius: "50%", background: C.accent, transform: `scale(${Math.max(0, sel)})`}} />
                  </div>
                  <div style={{fontSize: 26, fontWeight: theme.type.weightHeavy, lineHeight: 1.3, letterSpacing: 0}}>With network everywhere</div>
                </div>
              </Abs>
            </PhoneFrame>
          </Entrance>
        </Abs>
        <Abs x={700} y={225}><Step n={1} text="Settings" delay={t137} /></Abs>
        <Abs x={700} y={350}><Step n={2} text="Google অথবা Security" delay={t138} /></Abs>
        <Abs x={700} y={475}><Step n={3} text="Find Hub" delay={t139} /></Abs>
        <Abs x={700} y={600}><Step n={4} text="Find your offline devices" delay={t140} /></Abs>
        <Abs x={700} y={725}><Step n={5} text="With network everywhere" delay={t142} last /></Abs>
      </Win>

      {/* পর্ব গ: কীভাবে কাজ করে — Hub-and-Spoke */}
      <Win from={t145} to={t160}>
        <Abs x={96} y={205} w={900}><Words text="এটি কীভাবে কাজ করে?" delay={t145} size={64} weight={theme.type.weightMid} color={C.textDim} /></Abs>
        <Link x1={250} y1={700} x2={700} y2={700} start={t150} dashed />
        <Link x1={700} y1={700} x2={1150} y2={520} start={t153} packet="lock" packetAt={t153 + 6} />
        <Link x1={1150} y1={520} x2={1620} y2={700} start={t155} packet="pin" packetAt={t155 + 6} />
        <Node cx={250} cy={700} d={190} icon="phone" label="আপনার ফোন (অফলাইন)" delay={t146} badge="x" />
        <Node cx={700} cy={700} d={190} icon="phone" label="কাছাকাছি Android ফোন" delay={t148} />
        <Node cx={1150} cy={520} d={250} icon="network" label="Find Hub নেটওয়ার্ক" delay={t153} tone="dark" />
        <Node cx={1620} cy={700} d={190} icon="phone" label="আপনি" delay={t155} badge="pin" />
        {frame >= t150 && (
          <Abs x={475 - 40} y={580} w={80} h={80} center style={{transform: `scale(${1 + pulse * 0.12})`}}>
            <Icon name="bluetooth" size={64} color={C.accentDeep} sw={2.2} />
          </Abs>
        )}
        <Abs x={560} y={470} w={800}><Chip text="এনক্রিপ্ট করা লোকেশন তথ্য" icon="lock" tone="accent" size={34} delay={t153 + 4} /></Abs>
        <Win from={t157}>
          <Abs x={0} y={940} w={1920} center><Chip text="নিজের ফোনে ইন্টারনেট না থাকলেও লোকেশন পাওয়ার সুযোগ" icon="check" tone="dark" size={36} delay={t157} /></Abs>
        </Win>
      </Win>

      {/* পর্ব ঘ: সতর্কতা */}
      <Win from={t160} to={t166}>
        <Abs x={310} y={235}>
          <Entrance delay={t160} y={40} sp="bouncy" from={0.92}>
            <Card style={{width: 1300, height: 290, padding: "0 56px", display: "flex", alignItems: "center", gap: 44}}>
              <Icon name="pin" size={130} color={C.textDim} sw={1.5} slash />
              <Words text="এটি সবসময় লাইভ GPS ট্র্যাকিং নয়" delay={t160 + 4} per={3} size={72} maxWidth={940} hi={["লাইভ"]} />
            </Card>
          </Entrance>
        </Abs>
        <Abs x={0} y={600} w={1920} center><Words text="ফলাফল নির্ভর করে" delay={t162} size={48} weight={theme.type.weightMid} color={C.textDim} align="center" maxWidth={900} /></Abs>
        <Abs x={0} y={700} w={1920} center>
          <div style={{display: "flex", gap: 36}}>
            <Chip text="কাছাকাছি নেটওয়ার্কের ডিভাইস" icon="network" size={38} delay={fac[0]} />
            <Chip text="Bluetooth" icon="bluetooth" size={38} delay={fac[1]} />
            <Chip text="ফোনের সামঞ্জস্য" icon="phone" size={38} delay={fac[2]} />
          </div>
        </Abs>
      </Win>

      {/* পর্ব ঙ: সারসংক্ষেপ */}
      <Win from={t166}>
        <Abs x={160} y={225} w={1600}><Words text="এগুলোও ঠিকভাবে চালু রাখুন" delay={t166} size={76} align="center" hi={["চালু"]} /></Abs>
        {([["pin", "Location"], ["bluetooth", "Bluetooth"], ["network", "Find Hub"]] as [IconName, string][]).map(([ic, label], i) => (
          <Abs key={label} x={270 + i * 480} y={420}>
            <Entrance delay={rec[i]} y={50} sp="bouncy" from={0.9}>
              <Card style={{width: 420, height: 400, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 24, position: "relative"}}>
                <div style={{width: 150, height: 150, borderRadius: "50%", background: alpha(C.accent, 0.14), display: "flex", alignItems: "center", justifyContent: "center"}}>
                  <Icon name={ic} size={84} color={C.accentDeep} sw={1.6} />
                </div>
                <div style={{fontSize: 48, fontWeight: theme.type.weightHeavy, letterSpacing: 0, lineHeight: 1.3}}>{label}</div>
                <div style={{position: "absolute", top: 22, right: 22, width: 64, height: 64, borderRadius: "50%", background: C.accent, display: "flex", alignItems: "center", justifyContent: "center"}}>
                  <Icon name="check" size={38} color={C.onHero} sw={2.8} />
                </div>
              </Card>
            </Entrance>
          </Abs>
        ))}
      </Win>

      <Sfx name="whoosh" at={t125} vol={0.22} />
      <Sfx name="pop" at={cap[0]} vol={0.28} />
      <Sfx name="pop" at={cap[2]} vol={0.28} rate={1.05} />
      <Sfx name="chime" at={t135} vol={0.28} />
      <Sfx name="click" at={t137} vol={0.28} />
      <Sfx name="click" at={t140} vol={0.28} rate={1.05} />
      <Sfx name="click" at={t143} vol={0.32} rate={0.95} />
      <Sfx name="pop" at={t146} vol={0.3} />
      <Sfx name="pop" at={t148} vol={0.3} rate={1.06} />
      <Sfx name="whoosh" at={t153} vol={0.2} rate={1.1} />
      <Sfx name="chime" at={t155} vol={0.28} />
      <Sfx name="thud" at={t160} vol={0.26} />
      <Sfx name="pop" at={fac[0]} vol={0.28} />
      <Sfx name="pop" at={rec[0]} vol={0.3} />
      <Sfx name="click" at={rec[2]} vol={0.3} />
    </>
  );
};
