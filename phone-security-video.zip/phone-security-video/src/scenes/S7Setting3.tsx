// সিন ৭ — সেটিংস ৩: Google Theft Protection (cue ৯৪–১২৪): পথ-নির্দেশ + দুটি Glass Card
import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {Abs, Breadcrumb, Chip, Entrance, Icon, Sfx, StepHeader, Win, Words, useSpring, type IconName} from "../components/ui";
import {alpha, theme} from "../theme";
import {useAt, useSpread} from "../timing";

const C = theme.colors;
const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
const CARD_W = 800;
const CARD_H = 560;

/** ছোট লুপ-অ্যানিমেশন: ঘটনা → লক */
const Demo: React.FC<{start: number; kind: "snatch" | "offline"}> = ({start, kind}) => {
  const frame = useCurrentFrame();
  const cycle = Math.max(0, frame - start) % 110;
  const run = interpolate(cycle, [0, 34], [0, 1], {easing: theme.ease.inOut, ...clamp});
  const pop = interpolate(cycle, [40, 52], [0, 1], {easing: theme.ease.out, ...clamp});
  const fade = interpolate(cycle, [96, 108], [1, 0], {...clamp});
  const icon: IconName = kind === "snatch" ? "phone" : "wifi";
  return (
    <div style={{position: "relative", height: 190, opacity: fade}}>
      <div style={{position: "absolute", left: 90, top: 30, transform: kind === "snatch" ? `translateX(${run * 250}px) rotate(${run * 14}deg)` : undefined, filter: kind === "snatch" && run > 0.02 && run < 0.98 ? `blur(${Math.sin(run * Math.PI) * 5}px)` : undefined}}>
        <Icon name={icon} size={120} color={C.text} sw={1.6} slash={kind === "offline" && run > 0.4} />
      </div>
      {kind === "snatch" && run > 0.02 && run < 0.98 &&
        [0, 1].map((k) => <div key={k} style={{position: "absolute", left: 40 + run * 250 - 100, top: 70 + k * 40, width: 110 * Math.sin(run * Math.PI), height: 7, borderRadius: 7, background: alpha(C.text, 0.22)}} />)}
      <div style={{position: "absolute", left: 470, top: 20, width: 140, height: 140, borderRadius: "50%", background: C.accent, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${pop})`, boxShadow: theme.shadow.card}}>
        <Icon name="lock" size={74} color={C.onHero} sw={1.8} />
      </div>
    </div>
  );
};

const Feature: React.FC<{title: string; text: string; note: string; at: number; tText: number; tNote: number; kind: "snatch" | "offline"}> = ({title, text, note, at, tText, tNote, kind}) => (
  <div style={{width: CARD_W, height: CARD_H, borderRadius: theme.radius.card, background: alpha(C.surface, 0.72), backdropFilter: "blur(16px)", border: `1.5px solid ${C.line}`, boxShadow: theme.shadow.card, padding: "38px 44px", display: "flex", flexDirection: "column", gap: 16}}>
    <div style={{fontSize: 48, fontWeight: theme.type.weightHeavy, letterSpacing: 0, lineHeight: 1.3}}>{title}</div>
    <Demo start={at + 10} kind={kind} />
    <Entrance delay={tText} y={16}><div style={{fontSize: 38, fontWeight: theme.type.weightMid, lineHeight: 1.4, letterSpacing: 0}}>{text}</div></Entrance>
    <div><Chip text={note} icon="shield" tone="accent" size={32} delay={tNote} /></div>
  </div>
);

export const S7Setting3: React.FC = () => {
  const t94 = useAt(94);
  const t96 = useAt(96);
  const t98 = useAt(98);
  const t101 = useAt(101);
  const t103 = useAt(103);
  const sp = useSpread(104, 105, 3);
  const t107 = useAt(107);
  const t109 = useAt(109);
  const t112 = useAt(112);
  const t115 = useAt(115);
  const t117 = useAt(117);
  const t119 = useAt(119);
  const t122 = useAt(122);
  const slide = useSpring(t117, theme.spring.smooth);
  const s = Math.max(0, Math.min(1, slide));

  return (
    <>
      <StepHeader n={3} title="Google Theft Protection অন রাখুন" at={t94} hi={["Theft", "Protection"]} />

      {/* cue ৯৬–১০০: Google-এর সুরক্ষা-ব্যবস্থা (খালি স্ক্রিন এড়াতে) */}
      <Win from={t96} to={t101}>
        <Abs x={0} y={250} w={1920} center>
          <Entrance delay={t96} sp="bouncy" from={0.7} y={40}>
            <div style={{width: 250, height: 250, borderRadius: "50%", background: alpha(C.accent, 0.14), display: "flex", alignItems: "center", justifyContent: "center"}}>
              <Icon name="shield" size={140} color={C.accentDeep} sw={1.5} />
            </div>
          </Entrance>
        </Abs>
        <Abs x={160} y={560} w={1600}><Words text="Android ফোনের জন্য Google-এর Theft Protection" delay={t96 + 4} per={3} size={72} align="center" hi={["Theft", "Protection"]} /></Abs>
        <Abs x={0} y={760} w={1920} center><Chip text="একটি সিকিউরিটি ব্যবস্থা" icon="check" tone="accent" size={44} delay={t98} /></Abs>
      </Win>

      <Abs x={96} y={212} w={1730}>
        <Breadcrumb items={["Settings", "Google", "All Services", "Personal and Device Safety", "Theft Protection"]} times={[t101, t103, sp[0], sp[1], sp[2]]} size={30} />
      </Abs>

      <Abs x={96} y={318} w={1000}><Words text="দুটি গুরুত্বপূর্ণ ফিচার" delay={t107} size={56} weight={theme.type.weightMid} color={C.textDim} /></Abs>

      {/* কার্ড ১: cue ১০৯–১১৬; কার্ড ২ আসতেই কার্ড ১ বাঁয়ে সরে যায় */}
      <Abs x={560 - s * 430} y={410}>
        <Entrance delay={t109} y={60} sp="smooth">
          <Feature title="Theft Detection Lock" text="ছিনিয়ে নিয়ে দৌড় দিলে স্ক্রিন অটো লক হতে পারে" note="ব্যক্তিগত তথ্য দেখার সুযোগ কমে" at={t109} tText={t112} tNote={t115} kind="snatch" />
        </Entrance>
      </Abs>
      <Win from={t117}>
        <Abs x={990} y={410}>
          <Entrance delay={t117} x={90} y={0} sp="smooth">
            <Feature title="Offline Device Lock" text="ইন্টারনেট থেকে বিচ্ছিন্ন হলে স্ক্রিন অটো লক হবে" note="অফলাইনে নিয়ে গিয়েও ক্ষতি করা কঠিন" at={t117} tText={t119} tNote={t122} kind="offline" />
          </Entrance>
        </Abs>
      </Win>

      <Sfx name="whoosh" at={t94} vol={0.22} />
      <Sfx name="chime" at={t96} vol={0.26} />
      <Sfx name="click" at={t101} vol={0.28} />
      <Sfx name="click" at={t103} vol={0.28} rate={1.05} />
      <Sfx name="click" at={sp[2]} vol={0.28} rate={0.95} />
      <Sfx name="pop" at={t109} vol={0.3} />
      <Sfx name="chime" at={t115} vol={0.26} />
      <Sfx name="swipe" at={t117} vol={0.2} rate={1.08} />
      <Sfx name="pop" at={t117} vol={0.3} rate={1.06} />
      <Sfx name="chime" at={t122} vol={0.26} rate={0.94} />
    </>
  );
};
