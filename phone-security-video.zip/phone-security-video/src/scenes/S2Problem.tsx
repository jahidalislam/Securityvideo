// সিন ২ — সমস্যা বনাম সমাধান (cue ৮–১৬): Before/After Split
import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {Abs, Card, Chip, Entrance, Icon, Sfx, Win, Words, useBreath, useSpring} from "../components/ui";
import {alpha, theme} from "../theme";
import {useAt} from "../timing";

const C = theme.colors;
const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

const Row: React.FC<{text: string; delay: number}> = ({text, delay}) => (
  <Entrance delay={delay} x={-24} y={10} sp="snappy">
    <div style={{display: "flex", alignItems: "center", gap: 18}}>
      <div style={{width: 58, height: 58, borderRadius: "50%", background: C.accent, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0}}>
        <Icon name="check" size={34} color={C.onHero} sw={2.6} />
      </div>
      <div style={{fontSize: 38, fontWeight: theme.type.weightMid, lineHeight: 1.4, letterSpacing: 0}}>{text}</div>
    </div>
  </Entrance>
);

export const S2Problem: React.FC = () => {
  const frame = useCurrentFrame();
  const t8 = useAt(8);
  const t10 = useAt(10);
  const t11 = useAt(11);
  const t12 = useAt(12);
  const t14 = useAt(14);
  const t15 = useAt(15);
  const float = useBreath(5, 30);
  const dim = interpolate(frame, [t11, t11 + 14], [1, 0.5], {easing: theme.ease.out, ...clamp});
  const divider = useSpring(t11, theme.spring.smooth);
  const shield = useSpring(t12 + 4, theme.spring.bouncy);

  return (
    <>
      {/* শিরোনাম */}
      <Win to={t11}>
        <Abs x={160} y={66} w={1600}><Words text="সবচেয়ে বড় সমস্যা" delay={t8} size={84} align="center" hi={["সমস্যা"]} /></Abs>
      </Win>
      <Win from={t11}>
        <Abs x={160} y={66} w={1600}><Words text="Android ফোনেই আছে সিকিউরিটি ফিচার" delay={t12} per={3} size={78} align="center" hi={["Android"]} /></Abs>
      </Win>

      {/* বাঁ কার্ড: চুরির পর */}
      <Abs x={150} y={260} w={780} h={690} style={{opacity: dim, transform: `scale(${0.88 + dim * 0.12})`}}>
        <Entrance delay={t8 + 10} sp="smooth">
          <Card style={{height: 690, padding: 48, display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 24}}>
            <Chip text="ফোন চুরির পর" size={36} />
            <div style={{flex: 1, width: "100%", display: "flex", alignItems: "center", justifyContent: "center", transform: `translateY(${float}px)`}}>
              <div style={{width: 230, height: 230, borderRadius: "50%", background: alpha(C.text, 0.07), display: "flex", alignItems: "center", justifyContent: "center"}}>
                <Icon name="alert" size={120} color={C.textDim} sw={1.5} />
              </div>
            </div>
            <Words text="বুঝি, সেটিংস অন করা দরকার ছিল" delay={t10} per={4} size={46} weight={theme.type.weightMid} color={C.text} />
          </Card>
        </Entrance>
      </Abs>

      {/* মাঝের বিভাজক */}
      <Abs x={957} y={290} w={6} h={630} style={{background: C.primary, borderRadius: 6, transform: `scaleY(${Math.max(0, divider)})`, transformOrigin: "50% 0%"}} />

      {/* ডান কার্ড: আগে থেকেই */}
      <Win from={t11}>
        <Abs x={990} y={260} w={780} h={690}>
          <Entrance delay={t11 + 4} x={60} y={0} sp="smooth">
            <Card style={{height: 690, padding: 48, display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 22}}>
              <Chip text="আগে থেকেই চালু" tone="accent" size={36} />
              <div style={{flex: 1, width: "100%", display: "flex", alignItems: "center", justifyContent: "center"}}>
                <div style={{width: 230, height: 230, borderRadius: "50%", background: alpha(C.accent, 0.14), display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${Math.max(0, shield)}) translateY(${float}px)`}}>
                  <Icon name="shield" size={126} color={C.accentDeep} sw={1.5} />
                </div>
              </div>
              <Row text="চোরের জন্য ফোন ব্যবহার করা কঠিন" delay={t14} />
              <Row text="ব্যক্তিগত তথ্য হাতানো কঠিন" delay={t15} />
            </Card>
          </Entrance>
        </Abs>
      </Win>

      <Sfx name="pop" at={t8 + 10} vol={0.3} />
      <Sfx name="whoosh" at={t11} vol={0.22} />
      <Sfx name="chime" at={t12 + 4} vol={0.28} />
      <Sfx name="click" at={t14} vol={0.3} />
      <Sfx name="click" at={t15} vol={0.3} rate={1.06} />
    </>
  );
};
