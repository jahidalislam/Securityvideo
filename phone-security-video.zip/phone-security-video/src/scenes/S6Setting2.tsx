// সিন ৬ — সেটিংস ২: Power Off-এর আগে পাসওয়ার্ড (cue ৭০–৯৩): বড় বাটন-ভিজ্যুয়াল + টগল-কার্ড
import React from "react";
import {interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {Abs, Breadcrumb, Card, Chip, Entrance, Icon, Sfx, StepHeader, Toggle, Win, Words, useSpring} from "../components/ui";
import {alpha, theme} from "../theme";
import {useAt} from "../timing";

const C = theme.colors;
const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

export const S6Setting2: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t70 = useAt(70);
  const t72 = useAt(72);
  const t76 = useAt(76);
  const t80 = useAt(80);
  const t81 = useAt(81);
  const t83 = useAt(83);
  const t84 = useAt(84);
  const t86 = useAt(86);
  const t88 = useAt(88);
  const t92 = useAt(92);
  const on = interpolate(frame, [t84, t84 + 12], [0, 1], {easing: theme.ease.out, ...clamp});
  const closed = frame >= t86;
  const bump = closed ? interpolate(spring({frame: frame - t86, fps, config: theme.spring.bouncy}), [0, 1], [1.4, 1]) : 1;
  const badge = useSpring(t76, theme.spring.bouncy);

  return (
    <>
      <StepHeader n={2} title="Power Off করার আগে পাসওয়ার্ড ব্যবহার" at={t70} hi={["পাসওয়ার্ড"]} />

      {/* বাঁ: বিশাল Power বাটন + তালার ব্যাজ */}
      <Abs x={130} y={330} w={420} h={420}>
        {[0, 1].map((k) => {
          const p = (((frame - t72 + k * 30) % 60) + 60) % 60 / 60;
          return <div key={k} style={{position: "absolute", left: 20 - p * 70, top: 20 - p * 70, width: 380 + p * 140, height: 380 + p * 140, borderRadius: "50%", border: `3px solid ${alpha(C.text, (1 - p) * 0.2)}`}} />;
        })}
        <Entrance delay={t72} sp="bouncy" from={0.7} y={40}>
          <div style={{width: 380, height: 380, marginLeft: 20, marginTop: 20, borderRadius: "50%", background: C.surface, border: `1.5px solid ${C.line}`, boxShadow: theme.shadow.card, display: "flex", alignItems: "center", justifyContent: "center"}}>
            <Icon name="power" size={190} color={C.text} sw={1.5} />
          </div>
        </Entrance>
        <Abs x={270} y={260} style={{transform: `scale(${Math.max(0, badge) * bump})`}}>
          <div style={{width: 150, height: 150, borderRadius: "50%", background: closed ? C.accent : C.text, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: theme.shadow.card}}>
            <Icon name={closed ? "lock" : "unlock"} size={80} color={C.onHero} sw={1.7} />
          </div>
        </Abs>
      </Abs>

      {/* ডান: সমস্যা → ফিচার */}
      <Win from={t72} to={t76}>
        <Abs x={760} y={260}>
          <Entrance delay={t72} x={50} y={0}>
            <Card style={{width: 1040, padding: "44px 48px", display: "flex", alignItems: "center", gap: 32}}>
              <Icon name="alert" size={84} color={C.textDim} sw={1.5} />
              <Words text="ফোনটিই বন্ধ করলে খুঁজে পাওয়া আরও কঠিন" delay={t72 + 4} per={3} size={52} maxWidth={820} hi={["কঠিন"]} />
            </Card>
          </Entrance>
        </Abs>
      </Win>
      <Win from={t76}>
        <Abs x={760} y={250}>
          <Entrance delay={t76} x={50} y={0}>
            <Card style={{width: 1040, padding: "36px 48px", display: "flex", alignItems: "center", gap: 28}}>
              <div style={{flex: 1}}>
                <div style={{fontSize: 46, fontWeight: theme.type.weightHeavy, letterSpacing: 0, lineHeight: 1.3}}>Require Password to Power Off</div>
                <div style={{marginTop: 10}}><Chip text="Power-off Verification" size={28} tone="accent" delay={t76 + 6} /></div>
              </div>
              <Toggle on={on} scale={0.95} />
            </Card>
          </Entrance>
        </Abs>
        <Abs x={760} y={470} w={1060}>
          <Breadcrumb items={["Settings", "Password & Security", "Power Off", "Enable"]} times={[t80, t81, t83, t84]} size={30} />
        </Abs>
      </Win>

      <Win from={t86}>
        <Abs x={760} y={640}>
          <Entrance delay={t86} x={50} y={0}>
            <Card style={{width: 1040, padding: "30px 48px", display: "flex", alignItems: "center", gap: 28, background: alpha(C.accent, 0.1)}}>
              <Icon name="lock" size={66} color={C.accentDeep} sw={1.7} />
              <Words text="পাসওয়ার্ড ছাড়া ফোন অফ হবে না" delay={t86 + 4} per={3} size={58} maxWidth={880} hi={["ছাড়া"]} />
            </Card>
          </Entrance>
        </Abs>
      </Win>
      <Win from={t88}>
        <Abs x={760} y={850}><Chip text="সব ফোনে এই ফিচার থাকে না" icon="alert" tone="accent" size={38} delay={t88} /></Abs>
      </Win>
      <Win from={t92}>
        <Abs x={760} y={850}><Chip text="অন্য সেটিংসগুলো অন রাখুন" icon="check" tone="dark" size={38} delay={t92} /></Abs>
      </Win>

      <Sfx name="whoosh" at={t70} vol={0.22} />
      <Sfx name="pop" at={t72} vol={0.3} />
      <Sfx name="pop" at={t76} vol={0.3} rate={1.06} />
      <Sfx name="click" at={t84} vol={0.32} />
      <Sfx name="chime" at={t86} vol={0.28} />
      <Sfx name="pop" at={t88} vol={0.28} rate={0.95} />
    </>
  );
};
