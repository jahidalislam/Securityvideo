// সিন ৫ — সেটিংস ১: লক স্ক্রিন থেকে Quick Settings বন্ধ (cue ৪৬–৬৯): Glossy UI Mockup
import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {Abs, Card, Chip, Entrance, Icon, PhoneFrame, Sfx, StepHeader, Toggle, Win, Words, useSpring} from "../components/ui";
import {alpha, theme} from "../theme";
import {useAt} from "../timing";

const C = theme.colors;
const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

const NameCard: React.FC<{text: string; delay: number}> = ({text, delay}) => (
  <Entrance delay={delay} x={50} y={0} sp="snappy">
    <Card style={{width: 980, height: 112, padding: "0 40px", display: "flex", alignItems: "center", gap: 24}}>
      <Icon name="sliders" size={50} color={C.accentDeep} />
      <div style={{fontSize: 40, fontWeight: theme.type.weightMid, letterSpacing: 0, lineHeight: 1.35}}>{text}</div>
    </Card>
  </Entrance>
);

export const S5Setting1: React.FC = () => {
  const frame = useCurrentFrame();
  const t46 = useAt(46);
  const t48 = useAt(48);
  const t49 = useAt(49);
  const t50 = useAt(50);
  const t52 = useAt(52);
  const t55 = useAt(55);
  const t57 = useAt(57);
  const t58 = useAt(58);
  const t59 = useAt(59);
  const t60 = useAt(60);
  const t61 = useAt(61);
  const t64 = useAt(64);
  const t66 = useAt(66);
  const t69 = useAt(69);
  const on = 1 - interpolate(frame, [t55, t55 + 12], [0, 1], {easing: theme.ease.out, ...clamp});
  const lock = useSpring(t61 + 4, theme.spring.bouncy);

  return (
    <>
      <StepHeader n={1} title="লক স্ক্রিন থেকে Quick Settings বন্ধ করুন" at={t46} hi={["বন্ধ"]} />

      {/* ফোন: Settings → সার্চ → টগল */}
      <Abs x={170} y={205}>
        <Entrance delay={t48} sp="smooth" y={60}>
          <PhoneFrame w={400}>
            <Abs x={34} y={86} w={290}><Words text="Settings" delay={t48 + 4} size={44} /></Abs>
            <Abs x={26} y={168} w={300} h={70}>
              <Entrance delay={t48 + 8} y={14}>
                <div style={{height: 70, borderRadius: 35, background: C.surface, border: `1.5px solid ${C.line}`, display: "flex", alignItems: "center", gap: 14, padding: "0 22px"}}>
                  <Icon name="search" size={30} color={C.textDim} />
                  <Words text="Lock Screen" delay={t49} per={4} size={28} weight={theme.type.weightMid} />
                </div>
              </Entrance>
            </Abs>
            <Abs x={26} y={262} w={300}><Chip text="Control Center" icon="sliders" size={24} delay={t50} /></Abs>
            <Abs x={22} y={360} w={308}>
              <Entrance delay={t52} y={30}>
                <div style={{background: C.surface, borderRadius: 28, border: `1.5px solid ${C.line}`, boxShadow: theme.shadow.soft, padding: "22px 20px", display: "flex", alignItems: "center", gap: 14}}>
                  <div style={{flex: 1, fontSize: 28, fontWeight: theme.type.weightHeavy, lineHeight: 1.3, letterSpacing: 0}}>Quick Settings on Lock Screen</div>
                  <Toggle on={on} scale={0.62} />
                </div>
              </Entrance>
            </Abs>
          </PhoneFrame>
        </Entrance>
      </Abs>

      {/* ডান কলাম: ধাপে ধাপে */}
      <Win from={t52} to={t55}>
        <Abs x={760} y={270}>
          <Entrance delay={t52} x={50} y={0}>
            <Card style={{width: 1040, padding: "44px 48px", display: "flex", alignItems: "center", gap: 36}}>
              <div style={{width: 130, height: 130, borderRadius: theme.radius.tile, background: alpha(C.accent, 0.14), display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0}}>
                <Icon name="arrowDown" size={72} color={C.accentDeep} />
              </div>
              <Words text="লক থাকা অবস্থায় Notification Drawer বা Control Center খোলা যায় কি না?" delay={t52 + 4} per={3} size={48} weight={theme.type.weightHeavy} maxWidth={760} />
            </Card>
          </Entrance>
        </Abs>
      </Win>
      <Win from={t55} to={t57}>
        <Abs x={760} y={360}><Chip text="Disable করে দিন" icon="x" tone="hero" size={76} delay={t55} /></Abs>
      </Win>
      <Win from={t57} to={t61}>
        <Abs x={760} y={250} w={1000}><Words text="কিছু ফোনে নাম হতে পারে" delay={t57} size={52} weight={theme.type.weightMid} color={C.textDim} /></Abs>
        <Abs x={760} y={360}><NameCard text="Open Control Center on Lock Screen" delay={t58} /></Abs>
        <Abs x={760} y={500}><NameCard text="Swipe down on Lock Screen" delay={t59} /></Abs>
        <Abs x={760} y={640}><NameCard text="Access Quick Settings on Lock Screen" delay={t60} /></Abs>
      </Win>
      <Win from={t61} to={t64}>
        <Abs x={760} y={290}>
          <Entrance delay={t61} x={50} y={0}>
            <Card style={{width: 1040, padding: "48px 52px", display: "flex", alignItems: "center", gap: 40}}>
              <div style={{width: 170, height: 170, borderRadius: "50%", background: alpha(C.accent, 0.14), display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${Math.max(0, lock)})`, flexShrink: 0}}>
                <Icon name="lock" size={90} color={C.accentDeep} sw={1.6} />
              </div>
              <Words text="লক অবস্থায় কেউ নেটওয়ার্ক সেটিংস বদলাতে পারবে না" delay={t61 + 6} per={3} size={52} maxWidth={720} hi={["পারবে"]} />
            </Card>
          </Entrance>
        </Abs>
      </Win>
      <Win from={t64}>
        <Abs x={760} y={250}>
          <Entrance delay={t64} x={50} y={0}>
            <Card style={{width: 1040, padding: "40px 48px", display: "flex", alignItems: "center", gap: 32, background: alpha(C.accent, 0.1)}}>
              <Icon name="alert" size={72} color={C.accentDeep} sw={1.6} />
              <div style={{fontSize: 52, fontWeight: theme.type.weightHeavy, letterSpacing: 0, lineHeight: 1.4}}>সব Android ফোনে এই অপশন নেই</div>
            </Card>
          </Entrance>
        </Abs>
        <Abs x={760} y={470}><Chip text="Airplane Mode আলাদাভাবে নিয়ন্ত্রণ" icon="plane" size={42} delay={t66} /></Abs>
        <Abs x={760} y={600}><Chip text="আপনার ফোনে পরীক্ষা করে নিন" icon="search" tone="accent" size={42} delay={t69} /></Abs>
      </Win>

      <Sfx name="whoosh" at={t48} vol={0.22} />
      <Sfx name="pop" at={t52} vol={0.3} />
      <Sfx name="click" at={t55 + 2} vol={0.32} />
      <Sfx name="pop" at={t58} vol={0.28} />
      <Sfx name="pop" at={t59} vol={0.28} rate={1.06} />
      <Sfx name="pop" at={t60} vol={0.28} rate={0.94} />
      <Sfx name="chime" at={t61 + 4} vol={0.28} />
      <Sfx name="pop" at={t64} vol={0.28} />
    </>
  );
};
