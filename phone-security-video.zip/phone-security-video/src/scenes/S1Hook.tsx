// সিন ১ — হুক (cue ১–৭): Kinetic Typography + ফোন ছিনতাইয়ের মোশন
import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {Abs, Chip, Entrance, Icon, PhoneFrame, Sfx, Win, Words, useBreath, useSpring} from "../components/ui";
import {alpha, theme} from "../theme";
import {useAt} from "../timing";

const C = theme.colors;
const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

export const S1Hook: React.FC = () => {
  const frame = useCurrentFrame();
  const t2 = useAt(2);
  const t4 = useAt(4);
  const t5 = useAt(5);
  const t6 = useAt(6);
  const t7 = useAt(7);
  const float = useBreath(8, 26);

  // ছিনিয়ে নেওয়া: ডানে দ্রুত ছুটে যায় (exit-ইজিং), ঝাপসা হয়
  const run = interpolate(frame, [t2, t2 + 16], [0, 1], {easing: theme.ease.in, ...clamp});
  const gone = frame >= t2 + 17;
  const q = useSpring(t7, theme.spring.bouncy);

  return (
    <>
      {/* রাস্তা: চলমান ড্যাশ */}
      <Win to={t7}>
        <Abs x={0} y={880} w={1920} h={8} style={{backgroundImage: `repeating-linear-gradient(90deg, ${alpha(C.text, 0.2)} 0 70px, transparent 70px 140px)`, backgroundPosition: `${-frame * 6}px 0`, borderRadius: 8}} />
      </Win>

      {/* বাঁ দিকের লাইন A → B */}
      <Win to={t2}>
        <Abs x={110} y={330} w={980}>
          <Words text="একবার ভাবুন তো, আপনি রাস্তায় হাঁটছেন।" delay={4} per={3} size={84} weight={theme.type.weightHeavy} hi={["রাস্তায়"]} />
        </Abs>
      </Win>
      <Win from={t2} to={t7}>
        <Abs x={110} y={290} w={1040}>
          <Words text="ফোনটা ছিনিয়ে নিয়ে দৌড় দিল!" delay={t2 + 2} per={4} size={theme.type.hero} weight={theme.type.weightHeavy} hi={["ছিনিয়ে"]} />
        </Abs>
      </Win>

      {/* ফোন */}
      {!gone && (
        <Abs x={1330} y={236} style={{transform: `translate(${run * 1150}px, ${float * (1 - run)}px) rotate(${run * 16}deg)`, filter: run > 0.05 ? `blur(${run * 9}px)` : undefined}}>
          <Entrance delay={3} sp="bouncy" y={60}>
            <PhoneFrame w={300}>
              <Abs x={0} y={0} w={300} h={606} center>
                <Icon name="shield" size={120} color={C.accent} sw={1.6} />
              </Abs>
            </PhoneFrame>
          </Entrance>
        </Abs>
      )}
      {/* গতির দাগ */}
      {run > 0 && run < 1 &&
        [0, 1, 2].map((k) => {
          const w = 420 * Math.sin(run * Math.PI);
          return <Abs key={k} x={1330 + run * 1150 - w + 150} y={470 + k * 74} w={w} h={9} style={{background: alpha(C.text, 0.22), borderRadius: 9}} />;
        })}

      {/* চোরের তিনটি চেষ্টা: cue ৪, ৫, ৬ */}
      <Win from={t4} to={t7}>
        <Abs x={1210} y={250}><Chip text="ইন্টারনেট বন্ধ" icon="wifi" slash size={46} delay={t4} /></Abs>
        <Abs x={1210} y={400}><Chip text="Airplane Mode" icon="plane" size={46} delay={t5} /></Abs>
        <Abs x={1210} y={550}><Chip text="ফোন Power Off" icon="power" size={46} delay={t6} /></Abs>
      </Win>

      {/* প্রশ্ন: cue ৭ */}
      <Win from={t7}>
        <Abs x={0} y={110} w={1920} h={420} center>
          {[0, 1, 2].map((k) => {
            const p = ((frame - t7 + k * 20) % 60 + 60) % 60 / 60;
            return <div key={k} style={{position: "absolute", width: 170 + p * 460, height: 170 + p * 460, borderRadius: "50%", border: `4px solid ${alpha(C.primary, (1 - p) * 0.55)}`}} />;
          })}
          <div style={{width: 170, height: 170, borderRadius: "50%", background: C.text, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${Math.max(0, q)})`, boxShadow: theme.shadow.card}}>
            <Icon name="pin" size={92} color={C.bg} sw={1.7} />
          </div>
        </Abs>
        <Abs x={160} y={590} w={1600}>
          <Words text="কীভাবে ফোনটি খুঁজে বের করবেন?" delay={t7 + 6} per={4} size={96} align="center" hi={["খুঁজে"]} />
        </Abs>
      </Win>

      <Sfx name="whoosh" at={3} vol={0.22} />
      <Sfx name="thud" at={t2} vol={0.3} />
      <Sfx name="swipe" at={t2} vol={0.2} rate={1.12} />
      <Sfx name="pop" at={t4} vol={0.3} />
      <Sfx name="pop" at={t5} vol={0.3} rate={1.07} />
      <Sfx name="pop" at={t6} vol={0.3} rate={0.93} />
      <Sfx name="chime" at={t7} vol={0.28} />
    </>
  );
};
