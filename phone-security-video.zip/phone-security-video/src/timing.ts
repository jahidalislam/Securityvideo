// timing.ts — সব সময় এখানে SRT (cues.json) থেকে হিসাব হয়; হাতে কোনো ফ্রেম বসানো নেই।
import {createContext, useContext} from "react";
import cuesJson from "./cues.json";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

export type Cue = {id: number; start: number; end: number; text: string};
const CUES = cuesJson as Cue[];
const byId = new Map<number, Cue>(CUES.map((c) => [c.id, c]));
const get = (id: number) => {
  const c = byId.get(id);
  if (!c) throw new Error(`SRT-তে cue ${id} নেই`);
  return c;
};

export const msToFrame = (ms: number) => Math.round((ms / 1000) * FPS);
export const cueStart = (id: number) => msToFrame(get(id).start);
export const cueEnd = (id: number) => msToFrame(get(id).end);

export const LEAD = 5; // ভিজ্যুয়াল কথার ৪-৬ ফ্রেম আগে ঢোকে
export const TAIL = 30; // শেষ cue-র পরে ১ সেকেন্ড স্থির সমাপ্তি
export const LAST_CUE = CUES[CUES.length - 1].id;

// সিনের সীমা = cue-র সীমা
const DEFS = [
  {key: "hook", first: 1},
  {key: "problem", first: 8},
  {key: "preview", first: 17},
  {key: "thief", first: 26},
  {key: "s1", first: 46},
  {key: "s2", first: 70},
  {key: "s3", first: 94},
  {key: "s4", first: 125},
  {key: "s5", first: 169},
] as const;

export type SceneKey = (typeof DEFS)[number]["key"];
export type SceneDef = {key: SceneKey; from: number; duration: number; index: number; last: boolean};

export const SCENES: SceneDef[] = DEFS.map((d, i) => {
  const from = i === 0 ? 0 : cueStart(d.first);
  const next = DEFS[i + 1];
  const to = next ? cueStart(next.first) : cueEnd(LAST_CUE) + TAIL;
  return {key: d.key, from, duration: to - from, index: i, last: i === DEFS.length - 1};
});

export const TOTAL_FRAMES = SCENES[SCENES.length - 1].from + SCENES[SCENES.length - 1].duration;

// সিনের শুরুর অ্যাবসোলিউট ফ্রেম
export const SceneBase = createContext(0);

/** cue-র সিন-লোকাল ফ্রেম (LEAD ফ্রেম আগে) */
export const useAt = (id: number, lead: number = LEAD) => {
  const base = useContext(SceneBase);
  return Math.max(0, cueStart(id) - lead - base);
};

/** cue-পরিসরে n টি আইটেম সমান ব্যবধানে */
export const useSpread = (firstId: number, lastId: number, n: number) => {
  const base = useContext(SceneBase);
  const a = cueStart(firstId) - LEAD - base;
  const b = cueEnd(lastId) - LEAD - base;
  return Array.from({length: n}, (_, i) => Math.max(0, Math.round(a + ((b - a) * i) / n)));
};

/** সিনের মোট দৈর্ঘ্য (লোকাল) */
export const useSceneEnd = () => {
  const base = useContext(SceneBase);
  const s = SCENES.find((x) => x.from === base);
  return s ? s.duration : 0;
};
