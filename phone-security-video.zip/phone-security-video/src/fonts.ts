// Hind Siliguri: বাংলা যুক্তাক্ষর ঠিকভাবে আসে। Remotion লোড শেষ না হওয়া পর্যন্ত রেন্ডার ধরে রাখে।
import {loadFont} from "@remotion/google-fonts/HindSiliguri";

export const {fontFamily} = loadFont("normal", {
  weights: ["400", "500", "600", "700"],
  subsets: ["bengali", "latin"],
});
