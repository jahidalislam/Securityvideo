import React from "react";
import {AbsoluteFill} from "remotion";
import {BgMesh, Grade, Grain, Vignette} from "./components/Backdrop";
import {PreviewAudio} from "./components/PreviewAudio";
import {Scene} from "./components/Scene";
import {S1Hook} from "./scenes/S1Hook";
import {S2Problem} from "./scenes/S2Problem";
import {S3Preview} from "./scenes/S3Preview";
import {S4Thief} from "./scenes/S4Thief";
import {S5Setting1} from "./scenes/S5Setting1";
import {S6Setting2} from "./scenes/S6Setting2";
import {S7Setting3} from "./scenes/S7Setting3";
import {S8Setting4} from "./scenes/S8Setting4";
import {S9Setting5} from "./scenes/S9Setting5";
import {theme} from "./theme";
import {SCENES, type SceneKey} from "./timing";

const VIEW: Record<SceneKey, React.FC> = {
  hook: S1Hook,
  problem: S2Problem,
  preview: S3Preview,
  thief: S4Thief,
  s1: S5Setting1,
  s2: S6Setting2,
  s3: S7Setting3,
  s4: S8Setting4,
  s5: S9Setting5,
};

export const Main: React.FC = () => (
  <AbsoluteFill style={{background: theme.colors.bg, color: theme.colors.text, fontFamily: theme.fonts.display}}>
    <style>{"*, *::before, *::after { box-sizing: border-box; }"}</style>
    <BgMesh />
    {SCENES.map((def) => {
      const View = VIEW[def.key];
      return (
        <Scene key={def.key} def={def}>
          <View />
        </Scene>
      );
    })}
    <Grade />
    <Grain />
    <Vignette />
    <PreviewAudio />
  </AbsoluteFill>
);
