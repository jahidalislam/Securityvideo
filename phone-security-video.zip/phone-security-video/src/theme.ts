// theme.ts — রং, ইজিং, spring, ফন্ট, গোলাকার ভাব, ছায়া: সবকিছুর একমাত্র উৎস।
// কম্পোনেন্টে সরাসরি রঙের কোড বা ইজিং লেখা নিষেধ।
import {Easing} from "remotion";
import {fontFamily} from "./fonts";

// Warm Paper স্কিম
const base = {
  bg: "#FFF8F0",
  primary: "#E4572E", // হিরো রং
  accent: "#17A398",
  text: "#2B2118",
};

export const alpha = (hex: string, a: number) => {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
};

export const theme = {
  colors: {
    ...base,
    bgAlt: "#FBEBDD",
    surface: "#FFFFFF",
    textDim: "#7A6A5C",
    accentDeep: "#0F7D73", // accent-এর গাঢ় রূপ: টেক্সটের জন্য
    onHero: "#FFFFFF",
    line: "rgba(43, 33, 24, 0.12)",
    glow: "rgba(228, 87, 46, 0.35)",
  },
  fonts: {
    display: fontFamily,
    body: fontFamily,
  },
  radius: {card: 36, tile: 28, chip: 999, screen: 22},
  shadow: {
    card: "0 34px 60px -28px rgba(43, 33, 24, 0.30), 0 2px 0 rgba(255,255,255,0.9) inset",
    soft: "0 18px 36px -22px rgba(43, 33, 24, 0.30)",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    bouncy: {damping: 11, stiffness: 170, mass: 0.7},
  },
  // সব ফন্ট-সাইজ ও ওজন এক জায়গায়
  type: {hero: 112, title: 68, body: 40, small: 32, weightHeavy: 700, weightMid: 600, weightBody: 500},
} as const;
