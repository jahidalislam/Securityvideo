// ছোট, নরম UI-ধাঁচের SFX সিন্থেসাইজ (কোনো ডাউনলোড নেই, সম্পূর্ণ ডিটারমিনিস্টিক)
// pop, click, whoosh, swipe, chime, thud -> public/sfx/*.wav (16-bit mono 44.1kHz)
import fs from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";

const SR = 44100;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const out = path.join(root, "public", "sfx");
fs.mkdirSync(out, {recursive: true});

let seed = 1234567;
const rnd = () => {
  seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
const noise = () => rnd() * 2 - 1;
const buf = (sec) => new Float32Array(Math.round(sec * SR));

// ফিল্টার
const lowpass = (x, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  return x.map((v) => (y += a * (v - y)));
};
const highpass = (x, fc) => {
  const lp = lowpass(x, fc);
  return x.map((v, i) => v - lp[i]);
};
// স্টেট-ভ্যারিয়েবল ব্যান্ডপাস, সময়ের সাথে বদলানো সেন্টার ফ্রিকোয়েন্সি
const sweepBand = (x, f0, f1, q) => {
  let low = 0, band = 0;
  return x.map((v, i) => {
    const f = f0 + (f1 - f0) * (i / x.length);
    const k = 2 * Math.sin((Math.PI * f) / SR);
    low += k * band;
    const high = v - low - band / q;
    band += k * high;
    return band;
  });
};
// খুব ছোট reverb (কম্ব ডিলে)
const tinyReverb = (x, mix = 0.14) => {
  const y = Float32Array.from(x);
  for (const [ms, g] of [[19, 0.32], [31, 0.24], [47, 0.16]]) {
    const d = Math.round((ms / 1000) * SR);
    for (let i = d; i < y.length; i++) y[i] += y[i - d] * g * mix * 3;
  }
  return y;
};
const env = (i, n, atk, decayK) => {
  const t = i / SR;
  const a = Math.min(1, t / atk);
  return a * a * (3 - 2 * a) * Math.exp(-t * decayK);
};
const fadeEdges = (x, inS, outS) => {
  const a = Math.round(inS * SR), b = Math.round(outS * SR);
  for (let i = 0; i < a; i++) x[i] *= i / a;
  for (let i = 0; i < b; i++) x[x.length - 1 - i] *= i / b;
  return x;
};

const sounds = {
  // soft pop: দ্রুত নিচে নামা pitch সহ sine
  pop() {
    const x = buf(0.2); let ph = 0;
    for (let i = 0; i < x.length; i++) {
      const t = i / SR, f = 170 + 420 * Math.exp(-t * 38);
      ph += (2 * Math.PI * f) / SR;
      x[i] = Math.sin(ph) * env(i, x.length, 0.004, 20);
    }
    return fadeEdges(lowpass(x, 3800), 0, 0.02);
  },
  // crisp click: high-pass করা ছোট noise burst + হালকা বডি
  click() {
    const x = buf(0.09);
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      x[i] = noise() * Math.exp(-t * 120) * 0.9 + Math.sin(2 * Math.PI * 1500 * t) * Math.exp(-t * 90) * 0.35;
    }
    return fadeEdges(lowpass(highpass(x, 1800), 7000), 0.0006, 0.01);
  },
  // smooth whoosh: band-pass noise sweep + fade in/out
  whoosh() {
    const n = buf(0.7);
    for (let i = 0; i < n.length; i++) n[i] = noise();
    const x = sweepBand(n, 450, 2600, 1.6);
    for (let i = 0; i < x.length; i++) x[i] *= Math.pow(Math.sin(Math.PI * (i / x.length)), 1.6);
    return lowpass(x, 5200);
  },
  // ছোট swipe: দ্রুততর, উঁচু দিকে স্লাইড (সিন ট্রানজিশন)
  swipe() {
    const n = buf(0.36);
    for (let i = 0; i < n.length; i++) n[i] = noise();
    const x = sweepBand(n, 700, 3200, 1.9);
    for (let i = 0; i < x.length; i++) x[i] *= Math.pow(Math.sin(Math.PI * (i / x.length)), 1.3);
    return lowpass(x, 5500);
  },
  // chime/pluck: নরম ওভারটোনসহ ছোট decay
  chime() {
    const x = buf(0.5);
    const f = 659.25; // E5, ভারী/হাই-পিচ নয়
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      const s = Math.sin(2 * Math.PI * f * t) + 0.35 * Math.sin(2 * Math.PI * f * 2.0 * t) * Math.exp(-t * 14) + 0.15 * Math.sin(2 * Math.PI * f * 3.0 * t) * Math.exp(-t * 22);
      x[i] = s * env(i, x.length, 0.006, 8.5);
    }
    return fadeEdges(lowpass(x, 4200), 0, 0.06);
  },
  // খুব হালকা সফট থাড (হুক/মূল বার্তা)
  thud() {
    const x = buf(0.34); let ph = 0;
    for (let i = 0; i < x.length; i++) {
      const t = i / SR, f = 52 + 48 * Math.exp(-t * 16);
      ph += (2 * Math.PI * f) / SR;
      x[i] = Math.sin(ph) * env(i, x.length, 0.012, 10);
    }
    return fadeEdges(lowpass(x, 420), 0, 0.05);
  },
};

const TARGET_RMS_DB = -19, PEAK_CEIL = 0.85;
const rows = [];
for (const [name, fn] of Object.entries(sounds)) {
  let x = tinyReverb(fn());
  x = lowpass(x, 6500);
  const rms = Math.sqrt(x.reduce((s, v) => s + v * v, 0) / x.length);
  let g = Math.pow(10, TARGET_RMS_DB / 20) / rms;
  let peak = Math.max(...x.map(Math.abs)) * g;
  let limited = false;
  if (peak > PEAK_CEIL) { g *= PEAK_CEIL / peak; peak = PEAK_CEIL; limited = true; }
  const pcm = Buffer.alloc(44 + x.length * 2);
  pcm.write("RIFF", 0); pcm.writeUInt32LE(36 + x.length * 2, 4); pcm.write("WAVEfmt ", 8);
  pcm.writeUInt32LE(16, 16); pcm.writeUInt16LE(1, 20); pcm.writeUInt16LE(1, 22);
  pcm.writeUInt32LE(SR, 24); pcm.writeUInt32LE(SR * 2, 28); pcm.writeUInt16LE(2, 32); pcm.writeUInt16LE(16, 34);
  pcm.write("data", 36); pcm.writeUInt32LE(x.length * 2, 40);
  let clipped = 0;
  x.forEach((v, i) => {
    const s = v * g;
    if (Math.abs(s) >= 0.999) clipped++;
    pcm.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(s * 32767))), 44 + i * 2);
  });
  fs.writeFileSync(path.join(out, `${name}.wav`), pcm);
  const rmsOut = Math.sqrt(x.reduce((s, v) => s + (v * g) ** 2, 0) / x.length);
  rows.push({name, sec: (x.length / SR).toFixed(2), peakDb: (20 * Math.log10(peak)).toFixed(1), rmsDb: (20 * Math.log10(rmsOut)).toFixed(1), clipped, limited});
}
console.table(rows);
