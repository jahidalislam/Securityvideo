// SRT -> src/cues.json  (ms টাইমিং; ভিডিওর সব সময় এখান থেকেই আসে)
import fs from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const raw = fs.readFileSync(path.join(root, "subtitles.srt"), "utf8").replace(/\r/g, "");
const toMs = (t) => {
  const m = t.match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  return ((+m[1] * 60 + +m[2]) * 60 + +m[3]) * 1000 + +m[4];
};
const cues = raw
  .split(/\n\s*\n/)
  .map((b) => b.trim().split("\n"))
  .filter((l) => l.length >= 3 && l[1].includes("-->"))
  .map((l) => {
    const [a, b] = l[1].split("-->").map((s) => s.trim());
    return {id: +l[0], start: toMs(a), end: toMs(b), text: l.slice(2).join(" ").trim()};
  });
fs.writeFileSync(path.join(root, "src", "cues.json"), JSON.stringify(cues, null, 1));
console.log(`cues: ${cues.length}, last end: ${cues[cues.length - 1].end}ms`);
