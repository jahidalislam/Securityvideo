public/voiceover.mp3 রাখলে Studio প্রিভিউতে ভয়েসওভার বাজবে (src/config.ts-এ ফ্ল্যাগ)।
SRT বদলালে: npm run prep  (cues.json ও SFX আবার তৈরি হবে)
